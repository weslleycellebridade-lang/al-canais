package com.alcanais.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : BaseActivity() {

    private val serverUrl: String
        get() = getSharedPreferences("AL_CANAIS", MODE_PRIVATE)
            .getString("server_url", "http://z1sv.site:80") ?: "http://z1sv.site:80"

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var txtPlayerStatus: TextView
    private var streamId = ""
    private var tipo = "live"
    private var streamUrl = ""

    private val handler = Handler(Looper.getMainLooper())
    private var tentativaReconexao = 0
    private val maxTentativas = 5
    private var reconexaoAgendada = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        txtPlayerStatus = findViewById(R.id.txtPlayerStatus)
        streamId = intent.getStringExtra("stream_id") ?: ""
        tipo = intent.getStringExtra("tipo") ?: "live"

        if (streamId.isEmpty()) {
            txtPlayerStatus.text = "Conteúdo não identificado."
            return
        }
        iniciarPlayer()
    }

    private fun iniciarPlayer() {
        val preferencias = getSharedPreferences("AL_CANAIS", MODE_PRIVATE)
        val usuario = preferencias.getString("username", "") ?: ""
        val senha = preferencias.getString("password", "") ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {
            txtPlayerStatus.text = "Login não encontrado."
            return
        }

        val extensao = intent.getStringExtra("extensao") ?: "mp4"
        streamUrl = when (tipo) {
            "vod" -> "$serverUrl/movie/$usuario/$senha/$streamId.$extensao"
            "series" -> "$serverUrl/series/$usuario/$senha/$streamId.$extensao"
            else -> "$serverUrl/live/$usuario/$senha/$streamId.ts"
        }

        liberarPlayer()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_BUFFERING -> {
                            txtPlayerStatus.visibility = View.VISIBLE
                            txtPlayerStatus.text = if (tentativaReconexao > 0) "Reconectando..." else "Carregando..."
                        }
                        Player.STATE_READY -> {
                            tentativaReconexao = 0
                            reconexaoAgendada = false
                            txtPlayerStatus.visibility = View.GONE
                        }
                        Player.STATE_ENDED -> {
                            if (tipo == "live") agendarReconexao()
                            else {
                                txtPlayerStatus.visibility = View.VISIBLE
                                txtPlayerStatus.text = "Reprodução encerrada."
                            }
                        }
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    if (tipo == "live") agendarReconexao()
                    else {
                        txtPlayerStatus.visibility = View.VISIBLE
                        txtPlayerStatus.text = "Erro ao reproduzir:\n${error.errorCodeName}"
                    }
                }
            })
            exo.setMediaItem(MediaItem.fromUri(streamUrl))
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    private fun agendarReconexao() {
        if (reconexaoAgendada || isFinishing || isDestroyed) return
        if (tentativaReconexao >= maxTentativas) {
            txtPlayerStatus.visibility = View.VISIBLE
            txtPlayerStatus.text = "Sinal interrompido. Pressione voltar e tente novamente."
            return
        }
        tentativaReconexao++
        reconexaoAgendada = true
        txtPlayerStatus.visibility = View.VISIBLE
        txtPlayerStatus.text = "Reconectando... ($tentativaReconexao/$maxTentativas)"

        handler.postDelayed({
            reconexaoAgendada = false
            if (!isFinishing && !isDestroyed) iniciarPlayer()
        }, 2000L)
    }

    private fun liberarPlayer() {
        playerView.player = null
        player?.release()
        player = null
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacksAndMessages(null)
        reconexaoAgendada = false
        liberarPlayer()
    }
}
