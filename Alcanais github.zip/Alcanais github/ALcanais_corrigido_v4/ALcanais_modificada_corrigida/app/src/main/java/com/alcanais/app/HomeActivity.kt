package com.alcanais.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : BaseActivity() {

    private lateinit var txtListaAtiva: TextView
    private lateinit var listaManager: ListaManager

    private lateinit var btnCanais: Button
    private lateinit var btnFilmes: Button
    private lateinit var btnSeries: Button
    private lateinit var btnConfiguracoes: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_home)

        listaManager = ListaManager(this)

        // ==========================================
        // COMPONENTES
        // ==========================================

        btnCanais = findViewById(R.id.btnCanais)
        btnFilmes = findViewById(R.id.btnFilmes)
        btnSeries = findViewById(R.id.btnSeries)
        btnConfiguracoes = findViewById(R.id.btnConfiguracoes)

        txtListaAtiva = findViewById(R.id.txtListaAtiva)

        atualizarListaAtiva()

        // ==========================================
        // FOCO VISUAL PARA TV
        // ==========================================

        configurarFoco(btnCanais)
        configurarFoco(btnFilmes)
        configurarFoco(btnSeries)
        configurarFoco(btnConfiguracoes)

        // ==========================================
        // CANAIS
        // ==========================================

        btnCanais.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    CanaisActivity::class.java
                )
            )
        }

        // ==========================================
        // FILMES
        // ==========================================

        btnFilmes.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    FilmesActivity::class.java
                )
            )
        }

        // ==========================================
        // SÉRIES
        // ==========================================

        btnSeries.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    SeriesActivity::class.java
                )
            )
        }

        // ==========================================
        // CONTAS
        // ==========================================

        btnConfiguracoes.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    ConfiguracoesActivity::class.java
                )
            )
        }

        // ==========================================
        // PRIMEIRO FOCO
        // ==========================================

        btnCanais.post {
            btnCanais.requestFocus()
        }
    }

    // ==============================================
    // DESTAQUE DO FOCO DO CONTROLE
    // ==============================================

    private fun configurarFoco(botao: Button) {

        botao.isFocusable = true
        botao.isFocusableInTouchMode = true

        botao.setOnFocusChangeListener { view, temFoco ->

            if (temFoco) {

                val destaque = GradientDrawable().apply {

                    // Quase transparente
                    setColor(Color.parseColor("#1800A8FF"))

                    // Contorno azul/ciano
                    setStroke(
                        5,
                        Color.parseColor("#00C8FF")
                    )

                    // Cantos arredondados
                    cornerRadius = 24f
                }

                view.background = destaque

                view.animate()
                    .scaleX(1.05f)
                    .scaleY(1.05f)
                    .setDuration(120)
                    .start()

            } else {

                view.background = null

                view.animate()
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .setDuration(120)
                    .start()
            }
        }
    }

    // ==============================================
    // LISTA ATIVA
    // ==============================================

    private fun atualizarListaAtiva() {

        val contaAtiva = listaManager.obterAtiva()

        if (contaAtiva != null) {

            txtListaAtiva.text =
                "● Lista ativa: ${contaAtiva.nome}"

        } else {

            txtListaAtiva.text =
                "Nenhuma lista selecionada"
        }
    }

    override fun onResume() {
        super.onResume()

        if (::listaManager.isInitialized) {
            atualizarListaAtiva()
        }
    }
}