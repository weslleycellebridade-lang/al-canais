package com.alcanais.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : BaseActivity() {

    // ==============================================
    // SERVIDORES DISPONÍVEIS
    // ==============================================

    private val servidores = listOf(
        "http://z1sv.site:80",
        "http://primelux.shop:80"
    )

    private lateinit var editUsername: EditText
    private lateinit var editPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var txtStatus: TextView
    private lateinit var txtClock: TextView

    private lateinit var listaManager: ListaManager

    private val handler =
        Handler(Looper.getMainLooper())

    private var adicionandoNovaLista = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        listaManager = ListaManager(this)

        editUsername =
            findViewById(R.id.editUsername)

        editPassword =
            findViewById(R.id.editPassword)

        btnLogin =
            findViewById(R.id.btnLogin)

        txtStatus =
            findViewById(R.id.txtStatus)

        txtClock =
            findViewById(R.id.txtClock)

        iniciarRelogio()

        adicionandoNovaLista =
            intent.getBooleanExtra(
                "adicionar_lista",
                false
            )

        btnLogin.setOnClickListener {
            realizarLoginManual()
        }

        if (adicionandoNovaLista) {

            prepararNovaLista()

        } else {

            verificarLoginSalvo()
        }
    }

    // ==============================================
    // NOVA LISTA
    // ==============================================

    private fun prepararNovaLista() {

        editUsername.setText("")
        editPassword.setText("")

        txtStatus.setTextColor(
            Color.parseColor("#9EADBF")
        )

        txtStatus.text =
            "Informe os dados da nova lista."

        btnLogin.text =
            "ADICIONAR LISTA"
    }

    // ==============================================
    // LOGIN SALVO
    // ==============================================

    private fun verificarLoginSalvo() {

        val contaAtiva =
            listaManager.obterAtiva()

        if (contaAtiva != null) {

            salvarLoginLocal(
                contaAtiva.usuario,
                contaAtiva.senha,
                contaAtiva.servidor
            )

            editUsername.setText(
                contaAtiva.usuario
            )

            editPassword.setText(
                contaAtiva.senha
            )

            iniciarLoginAutomatico(
                contaAtiva.usuario,
                contaAtiva.senha,
                contaAtiva.servidor
            )

            return
        }

        // Compatibilidade com versões anteriores

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            preferencias.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            preferencias.getString(
                "password",
                ""
            ) ?: ""

        val servidorSalvo =
            preferencias.getString(
                "server_url",
                ""
            ) ?: ""

        if (
            usuario.isEmpty() ||
            senha.isEmpty()
        ) {
            return
        }

        editUsername.setText(usuario)
        editPassword.setText(senha)

        iniciarLoginAutomatico(
            usuario,
            senha,
            servidorSalvo
        )
    }

    // ==============================================
    // LOGIN AUTOMÁTICO
    // ==============================================

    private fun iniciarLoginAutomatico(
        usuario: String,
        senha: String,
        servidorPreferencial: String = ""
    ) {

        btnLogin.isEnabled = false
        btnLogin.text = "CONECTANDO..."

        txtStatus.setTextColor(
            Color.parseColor("#9EADBF")
        )

        txtStatus.text =
            "Verificando sua conta..."

        validarAcesso(
            usuario,
            senha,
            loginAutomatico = true,
            servidorPreferencial = servidorPreferencial
        )
    }

    // ==============================================
    // LOGIN MANUAL
    // ==============================================

    private fun realizarLoginManual() {

        val usuario =
            editUsername.text
                .toString()
                .trim()

        val senha =
            editPassword.text
                .toString()
                .trim()

        if (
            usuario.isEmpty() ||
            senha.isEmpty()
        ) {

            mostrarErro(
                "Informe usuário e senha."
            )

            return
        }

        btnLogin.isEnabled = false

        btnLogin.text =
            if (adicionandoNovaLista) {
                "ADICIONANDO..."
            } else {
                "CONECTANDO..."
            }

        txtStatus.setTextColor(
            Color.parseColor("#9EADBF")
        )

        txtStatus.text =
            "Verificando acesso..."

        validarAcesso(
            usuario,
            senha,
            loginAutomatico = false
        )
    }

    // ==============================================
    // TESTA OS SERVIDORES
    // ==============================================

    private fun validarAcesso(
        usuario: String,
        senha: String,
        loginAutomatico: Boolean,
        servidorPreferencial: String = ""
    ) {

        thread {

            val usuarioCodificado =
                URLEncoder.encode(
                    usuario,
                    "UTF-8"
                )

            val senhaCodificada =
                URLEncoder.encode(
                    senha,
                    "UTF-8"
                )

            /*
             * Se existe servidor salvo para a conta,
             * ele será testado primeiro.
             *
             * Depois o aplicativo tenta os demais.
             */

            val servidoresParaTestar =
                mutableListOf<String>()

            if (
                servidorPreferencial.isNotEmpty() &&
                servidores.contains(servidorPreferencial)
            ) {
                servidoresParaTestar.add(
                    servidorPreferencial
                )
            }

            for (servidor in servidores) {

                if (
                    !servidoresParaTestar.contains(
                        servidor
                    )
                ) {

                    servidoresParaTestar.add(
                        servidor
                    )
                }
            }

            var encontrouResposta = false
            var contaEncontradaMasInativa = false

            for (servidor in servidoresParaTestar) {

                var conexao: HttpURLConnection? = null

                try {

                    runOnUiThread {

                        txtStatus.text =
                            "Conectando ao servidor..."
                    }

                    val endereco =
                        "$servidor/player_api.php" +
                                "?username=$usuarioCodificado" +
                                "&password=$senhaCodificada"

                    conexao =
                        URL(endereco)
                            .openConnection() as HttpURLConnection

                    conexao.requestMethod = "GET"

                    // Reduzimos para não esperar muito
                    // caso um dos DNS esteja indisponível.
                    conexao.connectTimeout = 8000
                    conexao.readTimeout = 8000

                    conexao.setRequestProperty(
                        "Accept",
                        "application/json"
                    )

                    val codigo =
                        conexao.responseCode

                    if (
                        codigo !=
                        HttpURLConnection.HTTP_OK
                    ) {

                        continue
                    }

                    encontrouResposta = true

                    val resposta =
                        conexao.inputStream
                            .bufferedReader()
                            .use {
                                it.readText()
                            }

                    val json =
                        JSONObject(resposta)

                    val userInfo =
                        json.optJSONObject(
                            "user_info"
                        ) ?: continue

                    val auth =
                        userInfo.optInt(
                            "auth",
                            0
                        )

                    val status =
                        userInfo.optString(
                            "status",
                            ""
                        )

                    if (
                        auth == 1 &&
                        status.equals(
                            "Active",
                            ignoreCase = true
                        )
                    ) {

                        // ==================================
                        // SERVIDOR CORRETO ENCONTRADO
                        // ==================================

                        if (adicionandoNovaLista) {

                            cadastrarNovaLista(
                                usuario,
                                senha,
                                servidor
                            )

                        } else {

                            salvarLoginLocal(
                                usuario,
                                senha,
                                servidor
                            )

                            cadastrarContaInicialSeNecessario(
                                usuario,
                                senha,
                                servidor
                            )

                            /*
                             * Se a conta já existe,
                             * garantimos que ela seja
                             * marcada como ativa.
                             */

                            val contaExistente =
                                listaManager
                                    .obterTodas()
                                    .firstOrNull {

                                        it.servidor.equals(
                                            servidor,
                                            ignoreCase = true
                                        ) &&
                                                it.usuario.equals(
                                                    usuario,
                                                    ignoreCase = true
                                                )
                                    }

                            if (contaExistente != null) {

                                listaManager.definirAtiva(
                                    contaExistente
                                )
                            }

                            abrirHome()
                        }

                        return@thread

                    } else {

                        contaEncontradaMasInativa = true
                    }

                } catch (e: Exception) {

                    /*
                     * Não mostramos erro imediatamente.
                     * Apenas tentamos o próximo servidor.
                     */

                    e.printStackTrace()

                } finally {

                    conexao?.disconnect()
                }
            }

            // ==============================================
            // NENHUM DOS SERVIDORES FUNCIONOU
            // ==============================================

            if (loginAutomatico) {
                limparLoginLocal()
            }

            when {

                contaEncontradaMasInativa -> {

                    mostrarErro(
                        "Usuário ou senha inválidos, ou conta inativa."
                    )
                }

                encontrouResposta -> {

                    mostrarErro(
                        "Não foi possível autenticar esta conta."
                    )
                }

                else -> {

                    mostrarErro(
                        "Não foi possível conectar aos servidores."
                    )
                }
            }
        }
    }

    // ==============================================
    // CADASTRAR NOVA LISTA
    // ==============================================

    private fun cadastrarNovaLista(
        usuario: String,
        senha: String,
        servidor: String
    ) {

        if (
            listaManager.existeConta(
                servidor,
                usuario
            )
        ) {

            runOnUiThread {

                mostrarErro(
                    "Esta lista já está cadastrada."
                )
            }

            return
        }

        val novaConta =
            ContaLista(
                id =
                    System.currentTimeMillis()
                        .toString(),

                nome =
                    "Lista ${listaManager.obterTodas().size + 1}",

                servidor =
                    servidor,

                usuario =
                    usuario,

                senha =
                    senha
            )

        listaManager.adicionar(
            novaConta
        )

        listaManager.definirAtiva(
            novaConta
        )

        salvarLoginLocal(
            usuario,
            senha,
            servidor
        )

        runOnUiThread {

            txtStatus.setTextColor(
                Color.parseColor("#00E676")
            )

            txtStatus.text =
                "Nova lista adicionada com sucesso."

            abrirHome()
        }
    }

    // ==============================================
    // PRIMEIRA CONTA
    // ==============================================

    private fun cadastrarContaInicialSeNecessario(
        usuario: String,
        senha: String,
        servidor: String
    ) {

        if (
            listaManager.existeConta(
                servidor,
                usuario
            )
        ) {
            return
        }

        val conta =
            ContaLista(
                id =
                    System.currentTimeMillis()
                        .toString(),

                nome =
                    "Lista Principal",

                servidor =
                    servidor,

                usuario =
                    usuario,

                senha =
                    senha
            )

        listaManager.adicionar(
            conta
        )

        listaManager.definirAtiva(
            conta
        )
    }

    // ==============================================
    // SALVAR LOGIN
    // ==============================================

    private fun salvarLoginLocal(
        usuario: String,
        senha: String,
        servidor: String
    ) {

        getSharedPreferences(
            "AL_CANAIS",
            MODE_PRIVATE
        )
            .edit()

            .putString(
                "username",
                usuario
            )

            .putString(
                "password",
                senha
            )

            .putString(
                "server_url",
                servidor
            )

            .apply()
    }

    // ==============================================
    // LIMPAR LOGIN
    // ==============================================

    private fun limparLoginLocal() {

        getSharedPreferences(
            "AL_CANAIS",
            MODE_PRIVATE
        )
            .edit()
            .remove("username")
            .remove("password")
            .remove("server_url")
            .apply()
    }

    // ==============================================
    // ABRIR HOME
    // ==============================================

    private fun abrirHome() {

        runOnUiThread {

            val intent =
                Intent(
                    this@MainActivity,
                    HomeActivity::class.java
                )

            intent.flags =
                Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK

            startActivity(intent)

            finish()
        }
    }

    // ==============================================
    // MOSTRAR ERRO
    // ==============================================

    private fun mostrarErro(
        mensagem: String
    ) {

        runOnUiThread {

            txtStatus.setTextColor(
                Color.parseColor(
                    "#FF5C68"
                )
            )

            txtStatus.text =
                mensagem

            btnLogin.text =
                if (adicionandoNovaLista) {
                    "ADICIONAR LISTA"
                } else {
                    "ENTRAR"
                }

            btnLogin.isEnabled = true
        }
    }

    // ==============================================
    // RELÓGIO
    // ==============================================

    private fun iniciarRelogio() {

        handler.post(
            object : Runnable {

                override fun run() {

                    val formato =
                        SimpleDateFormat(
                            "HH:mm",
                            Locale(
                                "pt",
                                "BR"
                            )
                        )

                    txtClock.text =
                        formato.format(
                            Date()
                        )

                    handler.postDelayed(
                        this,
                        1000
                    )
                }
            }
        )
    }

    override fun onDestroy() {

        handler.removeCallbacksAndMessages(
            null
        )

        super.onDestroy()
    }
}