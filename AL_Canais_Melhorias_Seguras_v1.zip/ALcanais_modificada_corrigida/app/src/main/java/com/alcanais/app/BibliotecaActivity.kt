package com.alcanais.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

class BibliotecaActivity : BaseActivity() {
    override val ajustarBarrasDoSistema = false
    private lateinit var lista: LinearLayout
    private lateinit var biblioteca: BibliotecaLocal
    private var secao = "favoritos"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        biblioteca = BibliotecaLocal(this)
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 18, 28, 18)
            setBackgroundColor(Color.rgb(2, 11, 24))
        }
        val cab = LinearLayout(this)
        fun botao(t: String, acao: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { acao() }; isFocusable = true
        }
        cab.addView(botao("← Voltar") { finish() })
        cab.addView(botao("★ Favoritos") { secao = "favoritos"; atualizar() })
        cab.addView(botao("◷ Recentes") { secao = "recentes"; atualizar() })
        raiz.addView(cab)
        val scroll = ScrollView(this)
        lista = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(lista); raiz.addView(scroll)
        setContentView(raiz)
        atualizar()
    }
    private fun atualizar() {
        lista.removeAllViews()
        val itens = biblioteca.listar(secao)
        if (itens.isEmpty()) {
            lista.addView(TextView(this).apply {
                text = "Nenhum conteúdo em ${if (secao == "favoritos") "Favoritos" else "Recentes"}."
                textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            })
        }
        itens.forEach { item ->
            lista.addView(Button(this).apply {
                text = item.optString("nome", "Conteúdo") + "  •  " + item.optString("tipo")
                isAllCaps = false
                setOnClickListener { abrir(item) }
                setOnLongClickListener {
                    biblioteca.favorito(item); atualizar(); true
                }
            })
        }
    }
    private fun abrir(item: JSONObject) {
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("stream_id", item.optString("id"))
            putExtra("tipo", item.optString("tipo", "live"))
            putExtra("canal_nome", item.optString("nome"))
            putExtra("extensao", item.optString("extensao", "mp4"))
        })
    }
    override fun onResume() { super.onResume(); if (::lista.isInitialized) atualizar() }
}
