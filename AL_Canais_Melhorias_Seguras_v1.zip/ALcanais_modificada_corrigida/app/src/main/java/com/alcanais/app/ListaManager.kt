package com.alcanais.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ContaLista(
    val id: String,
    val nome: String,
    val servidor: String,
    val usuario: String,
    val senha: String
)

class ListaManager(
    private val context: Context
) {

    private val preferencias =
        context.getSharedPreferences(
            "AL_CANAIS",
            Context.MODE_PRIVATE
        )

    fun obterTodas(): MutableList<ContaLista> {

        val resultado =
            mutableListOf<ContaLista>()

        val texto =
            preferencias.getString(
                "listas_salvas",
                "[]"
            ) ?: "[]"

        try {

            val array = JSONArray(texto)

            for (i in 0 until array.length()) {

                val obj = array.getJSONObject(i)

                resultado.add(
                    ContaLista(
                        id = obj.optString("id"),
                        nome = obj.optString("nome"),
                        servidor = obj.optString("servidor"),
                        usuario = obj.optString("usuario"),
                        senha = obj.optString("senha")
                    )
                )
            }

        } catch (_: Exception) {
        }

        return resultado
    }

    fun adicionar(
        conta: ContaLista
    ) {

        val contas = obterTodas()

        contas.add(conta)

        salvarTodas(contas)
    }

    fun renomear(
        id: String,
        novoNome: String
    ): Boolean {

        val nomeLimpo = novoNome.trim()

        if (nomeLimpo.isEmpty()) {
            return false
        }

        val contas = obterTodas()

        val indice =
            contas.indexOfFirst {
                it.id == id
            }

        if (indice == -1) {
            return false
        }

        val contaAtual = contas[indice]

        contas[indice] =
            contaAtual.copy(
                nome = nomeLimpo
            )

        salvarTodas(contas)

        return true
    }

    fun excluir(
        id: String
    ) {

        val contas = obterTodas()

        contas.removeAll {
            it.id == id
        }

        salvarTodas(contas)

        if (obterIdAtivo() == id) {

            preferencias
                .edit()
                .remove("lista_ativa_id")
                .apply()
        }
    }

    fun definirAtiva(
        conta: ContaLista
    ) {

        preferencias
            .edit()

            .putString(
                "lista_ativa_id",
                conta.id
            )

            .putString(
                "username",
                conta.usuario
            )

            .putString(
                "password",
                conta.senha
            )

            .putString(
                "server_url",
                conta.servidor
            )

            .apply()
    }

    fun obterAtiva(): ContaLista? {

        val id = obterIdAtivo()

        if (id.isEmpty()) {
            return null
        }

        return obterTodas()
            .firstOrNull {
                it.id == id
            }
    }

    fun obterIdAtivo(): String {

        return preferencias.getString(
            "lista_ativa_id",
            ""
        ) ?: ""
    }

    fun existeConta(
        servidor: String,
        usuario: String
    ): Boolean {

        return obterTodas().any {

            it.servidor.equals(
                servidor,
                ignoreCase = true
            ) &&
                    it.usuario.equals(
                        usuario,
                        ignoreCase = true
                    )
        }
    }

    private fun salvarTodas(
        contas: List<ContaLista>
    ) {

        val array = JSONArray()

        for (conta in contas) {

            val obj = JSONObject()

            obj.put(
                "id",
                conta.id
            )

            obj.put(
                "nome",
                conta.nome
            )

            obj.put(
                "servidor",
                conta.servidor
            )

            obj.put(
                "usuario",
                conta.usuario
            )

            obj.put(
                "senha",
                conta.senha
            )

            array.put(obj)
        }

        preferencias
            .edit()
            .putString(
                "listas_salvas",
                array.toString()
            )
            .apply()
    }
}