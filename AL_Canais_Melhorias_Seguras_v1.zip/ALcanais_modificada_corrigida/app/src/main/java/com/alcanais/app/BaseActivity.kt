package com.alcanais.app

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

open class BaseActivity : AppCompatActivity() {

    // Telas em tela cheia (Home com imagem, Player) desligam este ajuste
    protected open val ajustarBarrasDoSistema: Boolean = true

    // Cor que aparece atrás das barras do sistema
    protected open val corFundoSistema: String = "#07111F"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        aplicarMargemDasBarras()
    }

    // Evita que o conteúdo fique por baixo da barra de status,
    // da barra de navegação e do recorte (notch) da câmera
    private fun aplicarMargemDasBarras() {

        if (!ajustarBarrasDoSistema) return

        val raiz = findViewById<View>(android.R.id.content)

        raiz.setBackgroundColor(Color.parseColor(corFundoSistema))

        ViewCompat.setOnApplyWindowInsetsListener(raiz) { view, insets ->

            val barras =
                insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() or
                            WindowInsetsCompat.Type.displayCutout()
                )

            view.setPadding(
                barras.left,
                barras.top,
                barras.right,
                barras.bottom
            )

            WindowInsetsCompat.CONSUMED
        }
    }
}
