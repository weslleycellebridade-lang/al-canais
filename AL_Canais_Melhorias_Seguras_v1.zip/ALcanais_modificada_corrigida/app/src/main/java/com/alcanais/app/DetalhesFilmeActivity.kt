package com.alcanais.app

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class DetalhesFilmeActivity : BaseActivity() {

    private lateinit var imgCapa: ImageView
    private lateinit var txtTitulo: TextView
    private lateinit var txtMeta: TextView
    private lateinit var txtSinopse: TextView
    private lateinit var txtStatus: TextView
    private lateinit var btnAssistir: TextView

    private var streamId = ""
    private var nome = "Filme"
    private var extensao = "mp4"

    private val serverUrl: String
        get() = getSharedPreferences("AL_CANAIS", MODE_PRIVATE)
            .getString("server_url", "http://z1sv.site:80") ?: "http://z1sv.site:80"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalhes_filme)

        imgCapa = findViewById(R.id.imgCapaFilme)
        txtTitulo = findViewById(R.id.txtTituloDetalheFilme)
        txtMeta = findViewById(R.id.txtMetaFilme)
        txtSinopse = findViewById(R.id.txtSinopseFilme)
        txtStatus = findViewById(R.id.txtStatusDetalheFilme)
        btnAssistir = findViewById(R.id.btnAssistirFilme)

        findViewById<TextView>(R.id.btnVoltarDetalheFilme).setOnClickListener { finish() }

        streamId = intent.getStringExtra("stream_id") ?: ""
        nome = intent.getStringExtra("filme_nome") ?: "Filme"
        extensao = intent.getStringExtra("extensao") ?: "mp4"
        val capaInicial = intent.getStringExtra("capa") ?: ""

        txtTitulo.text = nome
        if (capaInicial.isNotBlank()) carregarImagem(capaInicial)

        btnAssistir.setOnClickListener {
            if (streamId.isNotBlank()) {
                startActivity(Intent(this, PlayerActivity::class.java).apply {
                    putExtra("stream_id", streamId)
                    putExtra("canal_nome", nome)
                    putExtra("tipo", "vod")
                    putExtra("extensao", extensao)
                })
            }
        }
        btnAssistir.requestFocus()

        if (streamId.isBlank()) {
            txtStatus.text = "Filme não identificado."
            btnAssistir.visibility = View.GONE
        } else {
            carregarDetalhes()
        }
    }

    private fun carregarDetalhes() {
        val prefs = getSharedPreferences("AL_CANAIS", MODE_PRIVATE)
        val usuario = prefs.getString("username", "") ?: ""
        val senha = prefs.getString("password", "") ?: ""
        if (usuario.isBlank() || senha.isBlank()) {
            txtStatus.text = "Login não encontrado."
            return
        }

        txtStatus.text = "Carregando informações..."
        thread {
            var conexao: HttpURLConnection? = null
            try {
                val u = URLEncoder.encode(usuario, "UTF-8")
                val s = URLEncoder.encode(senha, "UTF-8")
                val id = URLEncoder.encode(streamId, "UTF-8")
                val endereco = "$serverUrl/player_api.php?username=$u&password=$s&action=get_vod_info&vod_id=$id"
                conexao = URL(endereco).openConnection() as HttpURLConnection
                conexao.connectTimeout = 15000
                conexao.readTimeout = 15000
                if (conexao.responseCode != HttpURLConnection.HTTP_OK) return@thread
                val json = JSONObject(conexao.inputStream.bufferedReader().use { it.readText() })
                val info = json.optJSONObject("info") ?: JSONObject()
                val movieData = json.optJSONObject("movie_data") ?: JSONObject()

                val titulo = movieData.optString("name", info.optString("name", nome)).ifBlank { nome }
                val sinopse = info.optString("plot", info.optString("description", "Sinopse não disponível."))
                    .ifBlank { "Sinopse não disponível." }
                val genero = info.optString("genre", "")
                val ano = info.optString("releasedate", info.optString("releaseDate", ""))
                val duracao = info.optString("duration", "")
                val avaliacao = info.optString("rating", "")
                val capa = info.optString("movie_image", info.optString("cover_big", ""))
                val meta = listOf(ano, genero, duracao, if (avaliacao.isNotBlank()) "★ $avaliacao" else "")
                    .filter { it.isNotBlank() }.joinToString("  •  ")

                runOnUiThread {
                    nome = titulo
                    txtTitulo.text = titulo
                    txtMeta.text = meta
                    txtSinopse.text = sinopse
                    txtStatus.text = ""
                    if (capa.isNotBlank()) carregarImagem(capa)
                }
            } catch (_: Exception) {
                runOnUiThread { txtStatus.text = "Algumas informações não estão disponíveis." }
            } finally {
                conexao?.disconnect()
            }
        }
    }

    private fun carregarImagem(endereco: String) {
        thread {
            try {
                val conexao = URL(endereco).openConnection()
                conexao.connectTimeout = 10000
                conexao.readTimeout = 10000
                val bitmap = conexao.getInputStream().use { BitmapFactory.decodeStream(it) }
                runOnUiThread { if (bitmap != null) imgCapa.setImageBitmap(bitmap) }
            } catch (_: Exception) { }
        }
    }
}
