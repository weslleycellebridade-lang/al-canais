package com.alcanais.app

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

/**
 * Cria um ExoPlayer mais tolerante para IPTV:
 * - segue redirecionamentos http <-> https
 * - tempos de conexão/leitura maiores
 * - buffer um pouco maior para evitar travadas
 */
@OptIn(UnstableApi::class)
fun criarExoPlayer(context: Context): ExoPlayer {

    val fabricaHttp =
        DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(20000)
            .setUserAgent("ALCanais/1.0")

    val controleBuffer =
        DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                15000,
                50000,
                2500,
                5000
            )
            .build()

    return ExoPlayer.Builder(context)
        .setMediaSourceFactory(
            DefaultMediaSourceFactory(context)
                .setDataSourceFactory(fabricaHttp)
        )
        .setLoadControl(controleBuffer)
        .build()
}
