package com.alcanais.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class ListaSeriesActivity : BaseActivity() {

    private val serverUrl: String
        get() {
            return getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            ).getString(
                "server_url",
                "http://z1sv.site:80"
            ) ?: "http://z1sv.site:80"
        }

    private lateinit var container: LinearLayout
    private lateinit var txtStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_series)

        container = findViewById(R.id.containerSeries)
        txtStatus = findViewById(R.id.txtStatusListaSeries)

        findViewById<TextView>(R.id.btnVoltarListaSeries)
            .setOnClickListener { finish() }

        val categoriaId =
            intent.getStringExtra("categoria_id") ?: ""

        val nome =
            intent.getStringExtra("categoria_nome") ?: "SÉRIES"

        findViewById<TextView>(R.id.txtTituloSeries).text =
            nome.uppercase()

        carregarSeries(categoriaId)
    }

    private fun carregarSeries(categoriaId: String) {

        val prefs =
            getSharedPreferences("AL_CANAIS", MODE_PRIVATE)

        val usuario = prefs.getString("username", "") ?: ""
        val senha = prefs.getString("password", "") ?: ""

        thread {

            var conexao: HttpURLConnection? = null

            try {

                val u = URLEncoder.encode(usuario, "UTF-8")
                val s = URLEncoder.encode(senha, "UTF-8")
                val c = URLEncoder.encode(categoriaId, "UTF-8")

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$u" +
                            "&password=$s" +
                            "&action=get_series" +
                            "&category_id=$c"

                conexao =
                    URL(endereco).openConnection() as HttpURLConnection

                conexao.connectTimeout = 15000
                conexao.readTimeout = 15000

                val resposta =
                    conexao.inputStream.bufferedReader().use {
                        it.readText()
                    }

                val series = JSONArray(resposta)

                android.util.Log.d("ALCANAIS_SERIES", resposta)

                runOnUiThread {

                    container.removeAllViews()

                    txtStatus.text =
                        "${series.length()} séries encontradas"

                    for (i in 0 until series.length()) {

                        val serie = series.getJSONObject(i)

                        adicionarSerie(
                            serie.optString("name", "Série"),
                            serie.optString("series_id", "")
                        )
                    }
                }

            } catch (e: Exception) {

                mostrarErro(
                    "Não foi possível carregar as séries."
                )

            } finally {
                conexao?.disconnect()
            }
        }
    }

    private fun adicionarSerie(
        nome: String,
        seriesId: String
    ) {

        val item = TextView(this)

        item.text = "▶  $nome"
        item.textSize = 16f
        item.setTextColor(Color.WHITE)
        item.gravity = Gravity.CENTER_VERTICAL
        item.setPadding(32, 28, 32, 28)

        item.setBackgroundColor(
            Color.parseColor("#132238")
        )

        val params =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        params.setMargins(0, 0, 0, 12)
        item.layoutParams = params

        item.setOnClickListener {

            val intent =
                Intent(
                    this,
                    EpisodiosActivity::class.java
                )

            intent.putExtra("series_id", seriesId)
            intent.putExtra("serie_nome", nome)

            startActivity(intent)
        }

        container.addView(item)
    }

    private fun mostrarErro(mensagem: String) {
        runOnUiThread {
            txtStatus.text = mensagem
        }
    }
}