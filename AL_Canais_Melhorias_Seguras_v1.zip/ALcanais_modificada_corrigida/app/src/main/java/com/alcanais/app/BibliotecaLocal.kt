package com.alcanais.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Dados locais separados por conta; não altera autenticação nem listas IPTV. */
class BibliotecaLocal(private val context: Context) {
    private val prefs = context.getSharedPreferences("al_biblioteca_v1", Context.MODE_PRIVATE)
    private val conta get() = context.getSharedPreferences("AL_CANAIS", Context.MODE_PRIVATE)
        .getString("username", "") ?: ""
    private fun chave(tipo: String) = "${conta}_$tipo"
    fun listar(tipo: String): List<JSONObject> = try {
        val a = JSONArray(prefs.getString(chave(tipo), "[]"))
        (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    } catch (_: Exception) { emptyList() }
    private fun salvar(tipo: String, itens: List<JSONObject>) {
        val a = JSONArray(); itens.forEach { a.put(it) }
        prefs.edit().putString(chave(tipo), a.toString()).apply()
    }
    fun registrar(item: JSONObject) {
        val id = item.optString("tipo") + ":" + item.optString("id")
        salvar("recentes", (listOf(item) + listar("recentes").filterNot {
            it.optString("tipo") + ":" + it.optString("id") == id
        }).take(60))
    }
    fun favorito(item: JSONObject): Boolean {
        val id = item.optString("tipo") + ":" + item.optString("id")
        val atuais = listar("favoritos")
        val existe = atuais.any { it.optString("tipo") + ":" + it.optString("id") == id }
        salvar("favoritos", if (existe) atuais.filterNot {
            it.optString("tipo") + ":" + it.optString("id") == id
        } else listOf(item) + atuais)
        return !existe
    }
}
