package com.alcanais.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class ListaCanaisActivity : BaseActivity() {

    private val serverUrl: String
        get() {
            return getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            ).getString(
                "server_url",
                "http://z1sv.site:80"
            ) ?: "http://z1sv.site:80"
        }

    private lateinit var containerCanais: LinearLayout
    private lateinit var txtStatusLista: TextView
    private lateinit var txtTituloCategoria: TextView
    private lateinit var btnVoltarLista: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_canais)

        containerCanais = findViewById(R.id.containerCanais)
        txtStatusLista = findViewById(R.id.txtStatusLista)
        txtTituloCategoria = findViewById(R.id.txtTituloCategoria)
        btnVoltarLista = findViewById(R.id.btnVoltarLista)

        btnVoltarLista.setOnClickListener {
            finish()
        }

        val categoryId = intent.getStringExtra("categoria_id") ?: ""
        val categoryName = intent.getStringExtra("categoria_nome") ?: "CANAIS"

        txtTituloCategoria.text = categoryName.uppercase()

        if (categoryId.isEmpty()) {
            txtStatusLista.text = "Categoria não identificada."
            return
        }

        carregarCanais(categoryId)
    }

    private fun carregarCanais(categoryId: String) {

        txtStatusLista.text = "Carregando canais..."

        val preferencias = getSharedPreferences(
            "AL_CANAIS",
            MODE_PRIVATE
        )

        val usuario = preferencias.getString("username", "") ?: ""
        val senha = preferencias.getString("password", "") ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {
            txtStatusLista.text = "Login não encontrado."
            return
        }

        thread {

            var conexao: HttpURLConnection? = null

            try {

                val usuarioCodificado =
                    URLEncoder.encode(usuario, "UTF-8")

                val senhaCodificada =
                    URLEncoder.encode(senha, "UTF-8")

                val categoriaCodificada =
                    URLEncoder.encode(categoryId, "UTF-8")

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$usuarioCodificado" +
                            "&password=$senhaCodificada" +
                            "&action=get_live_streams" +
                            "&category_id=$categoriaCodificada"

                val url = URL(endereco)

                conexao = url.openConnection() as HttpURLConnection

                conexao.requestMethod = "GET"
                conexao.connectTimeout = 15000
                conexao.readTimeout = 15000

                val codigo = conexao.responseCode

                if (codigo != HttpURLConnection.HTTP_OK) {
                    mostrarErro("Erro do servidor: $codigo")
                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use { it.readText() }

                val canais = JSONArray(resposta)

                runOnUiThread {

                    containerCanais.removeAllViews()

                    if (canais.length() == 0) {
                        txtStatusLista.text =
                            "Nenhum canal encontrado nesta categoria."
                        return@runOnUiThread
                    }

                    txtStatusLista.text =
                        "${canais.length()} canais encontrados"

                    for (i in 0 until canais.length()) {

                        val canal = canais.getJSONObject(i)

                        val nome =
                            canal.optString(
                                "name",
                                "Canal"
                            )

                        val streamId =
                            canal.optString(
                                "stream_id",
                                ""
                            )

                        adicionarCanal(
                            nome,
                            streamId
                        )
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()

                mostrarErro(
                    "Não foi possível carregar os canais."
                )

            } finally {

                conexao?.disconnect()
            }
        }
    }

    private fun adicionarCanal(
        nome: String,
        streamId: String
    ) {

        val item = TextView(this)

        item.text = nome
        item.textSize = 16f
        item.setTextColor(Color.WHITE)

        item.setBackgroundColor(
            Color.parseColor("#132238")
        )

        item.gravity = Gravity.CENTER_VERTICAL

        item.setPadding(
            32,
            28,
            32,
            28
        )

        val parametros =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        parametros.setMargins(
            0,
            0,
            0,
            12
        )

        item.layoutParams = parametros

        item.setOnClickListener {

            val intent =
                android.content.Intent(
                    this,
                    PlayerActivity::class.java
                )

            intent.putExtra(
                "stream_id",
                streamId
            )

            intent.putExtra(
                "canal_nome",
                nome
            )

            startActivity(intent)
        }

        containerCanais.addView(item)
    }

    private fun mostrarErro(mensagem: String) {

        runOnUiThread {
            txtStatusLista.text = mensagem
        }
    }
}