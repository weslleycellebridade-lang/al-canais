package com.alcanais.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class ListaFilmesActivity : BaseActivity() {

    private val serverUrl: String
        get() {
            return getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            ).getString(
                "server_url",
                "http://z1sv.site:80"
            ) ?: "http://z1sv.site:80"
        }

    private lateinit var containerFilmes: LinearLayout
    private lateinit var txtStatus: TextView
    private lateinit var txtTitulo: TextView
    private lateinit var btnVoltar: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_filmes)

        containerFilmes =
            findViewById(R.id.containerFilmes)

        txtStatus =
            findViewById(R.id.txtStatusListaFilmes)

        txtTitulo =
            findViewById(R.id.txtTituloFilmes)

        btnVoltar =
            findViewById(R.id.btnVoltarListaFilmes)

        btnVoltar.setOnClickListener {
            finish()
        }

        val categoriaId =
            intent.getStringExtra("categoria_id") ?: ""

        val categoriaNome =
            intent.getStringExtra("categoria_nome") ?: "FILMES"

        txtTitulo.text = categoriaNome.uppercase()

        if (categoriaId.isEmpty()) {
            txtStatus.text = "Categoria não identificada."
            return
        }

        carregarFilmes(categoriaId)
    }

    private fun carregarFilmes(
        categoriaId: String
    ) {

        txtStatus.text = "Carregando filmes..."

        val preferencias =
            getSharedPreferences("AL_CANAIS", MODE_PRIVATE)

        val usuario =
            preferencias.getString("username", "") ?: ""

        val senha =
            preferencias.getString("password", "") ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {
            txtStatus.text = "Login não encontrado."
            return
        }

        thread {

            var conexao: HttpURLConnection? = null

            try {

                val usuarioCodificado =
                    URLEncoder.encode(usuario, "UTF-8")

                val senhaCodificada =
                    URLEncoder.encode(senha, "UTF-8")

                val categoriaCodificada =
                    URLEncoder.encode(categoriaId, "UTF-8")

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$usuarioCodificado" +
                            "&password=$senhaCodificada" +
                            "&action=get_vod_streams" +
                            "&category_id=$categoriaCodificada"

                conexao =
                    URL(endereco).openConnection() as HttpURLConnection

                conexao.requestMethod = "GET"
                conexao.connectTimeout = 15000
                conexao.readTimeout = 15000

                if (conexao.responseCode != HttpURLConnection.HTTP_OK) {
                    mostrarErro(
                        "Erro do servidor: ${conexao.responseCode}"
                    )
                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use { it.readText() }

                val filmes = JSONArray(resposta)

                runOnUiThread {

                    containerFilmes.removeAllViews()

                    if (filmes.length() == 0) {

                        txtStatus.text =
                            "Nenhum filme encontrado."

                        return@runOnUiThread
                    }

                    txtStatus.text =
                        "${filmes.length()} filmes encontrados"

                    for (i in 0 until filmes.length()) {

                        val filme =
                            filmes.getJSONObject(i)

                        val nome =
                            filme.optString(
                                "name",
                                "Filme"
                            )

                        val streamId =
                            filme.optString(
                                "stream_id",
                                ""
                            )

                        val extensao =
                            filme.optString(
                                "container_extension",
                                "mp4"
                            )

                        adicionarFilme(
                            nome,
                            streamId,
                            extensao
                        )
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()

                mostrarErro(
                    "Não foi possível carregar os filmes."
                )

            } finally {

                conexao?.disconnect()
            }
        }
    }

    private fun adicionarFilme(
        nome: String,
        streamId: String,
        extensao: String
    ) {

        val item = TextView(this)

        item.text = "🎬  $nome"
        item.textSize = 16f
        item.setTextColor(Color.WHITE)

        item.setBackgroundColor(
            Color.parseColor("#132238")
        )

        item.gravity = Gravity.CENTER_VERTICAL

        item.setPadding(
            32,
            28,
            32,
            28
        )

        val parametros =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        parametros.setMargins(
            0,
            0,
            0,
            12
        )

        item.layoutParams = parametros

        item.setOnClickListener {

            val intent =
                Intent(
                    this,
                    PlayerActivity::class.java
                )

            intent.putExtra(
                "stream_id",
                streamId
            )

            intent.putExtra(
                "canal_nome",
                nome
            )

            intent.putExtra(
                "tipo",
                "vod"
            )

            intent.putExtra(
                "extensao",
                extensao
            )

            startActivity(intent)
        }

        containerFilmes.addView(item)
    }

    private fun mostrarErro(
        mensagem: String
    ) {

        runOnUiThread {
            txtStatus.text = mensagem
        }
    }
}