package com.alcanais.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Dados locais separados por conta; não altera autenticação nem listas IPTV. */
class BibliotecaLocal(private val context: Context) {
    private val prefs = context.getSharedPreferences("al_biblioteca_v1", Context.MODE_PRIVATE)
    private val conta get() = context.getSharedPreferences("AL_CANAIS", Context.MODE_PRIVATE)
        .getString("username", "") ?: ""
    private fun chave(tipo: String) = "${conta}_$tipo"
    fun listar(tipo: String): List<JSONObject> = try {
        val a = JSONArray(prefs.getString(chave(tipo), "[]"))
        (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    } catch (_: Exception) { emptyList() }
    private fun salvar(tipo: String, itens: List<JSONObject>) {
        val a = JSONArray(); itens.forEach { a.put(it) }
        prefs.edit().putString(chave(tipo), a.toString()).apply()
    }
    fun registrar(item: JSONObject) = registrarEm("recentes", item)

    fun registrarEm(lista: String, item: JSONObject) {
        val id = item.optString("tipo") + ":" + item.optString("id")
        salvar(lista, (listOf(item) + listar(lista).filterNot {
            it.optString("tipo") + ":" + it.optString("id") == id
        }).take(60))
    }

    fun removerDe(lista: String, tipo: String, id: String) {
        salvar(lista, listar(lista).filterNot {
            it.optString("tipo") == tipo && it.optString("id") == id
        })
    }

    // ---- progresso de reprodução (chave "vod:ID" ou "ep:ID") ----
    private fun lerProgresso(): JSONObject = try {
        JSONObject(prefs.getString("${conta}_prog", "{}") ?: "{}")
    } catch (_: Exception) { JSONObject() }

    fun progresso(chave: String): LongArray? {
        val a = lerProgresso().optJSONArray(chave) ?: return null
        return longArrayOf(a.optLong(0), a.optLong(1))
    }

    fun salvarProgresso(chave: String, posicao: Long, duracao: Long) {
        val o = lerProgresso()
        o.put(chave, JSONArray().put(posicao).put(duracao))
        while (o.length() > 500) {
            val primeira = o.keys().next()
            o.remove(primeira)
        }
        prefs.edit().putString("${conta}_prog", o.toString()).apply()
    }

    fun limparProgresso(chave: String) {
        val o = lerProgresso()
        o.remove(chave)
        prefs.edit().putString("${conta}_prog", o.toString()).apply()
    }

    /** Percentual (0-100) já assistido de todos os itens com progresso. */
    fun percentuais(): Map<String, Int> {
        val o = lerProgresso()
        val mapa = HashMap<String, Int>()
        val chaves = o.keys()
        while (chaves.hasNext()) {
            val k = chaves.next()
            val a = o.optJSONArray(k) ?: continue
            val pos = a.optLong(0)
            val dur = a.optLong(1)
            if (dur > 0 && pos > 0) mapa[k] = ((pos * 100) / dur).toInt().coerceIn(1, 99)
        }
        return mapa
    }
    // ---- episódios já assistidos (por série) ----
    private fun chaveVistos(serieId: String) = "${conta}_vistos_$serieId"
    fun vistos(serieId: String): Set<String> =
        (prefs.getString(chaveVistos(serieId), "") ?: "").split(",").filter { it.isNotEmpty() }.toSet()
    fun foiVisto(serieId: String, episodioId: String) = vistos(serieId).contains(episodioId)
    fun marcarVisto(serieId: String, episodioId: String, visto: Boolean) {
        if (serieId.isEmpty() || episodioId.isEmpty()) return
        val novo = vistos(serieId).toMutableSet()
        if (visto) novo.add(episodioId) else novo.remove(episodioId)
        prefs.edit().putString(chaveVistos(serieId), novo.joinToString(",")).apply()
    }
    fun favorito(item: JSONObject): Boolean {
        val id = item.optString("tipo") + ":" + item.optString("id")
        val atuais = listar("favoritos")
        val existe = atuais.any { it.optString("tipo") + ":" + it.optString("id") == id }
        salvar("favoritos", if (existe) atuais.filterNot {
            it.optString("tipo") + ":" + it.optString("id") == id
        } else listOf(item) + atuais)
        return !existe
    }
}

/** Ligações comuns de favoritos nos itens das listas (toque longo / segurar OK). */
object FavUi {

    fun ehFavorito(context: Context, tipo: String, id: String): Boolean =
        BibliotecaLocal(context).listar("favoritos").any {
            it.optString("tipo") == tipo && it.optString("id") == id
        }

    fun ligar(
        activity: android.app.Activity,
        item: android.widget.TextView,
        registro: JSONObject,
        aoAlterar: (() -> Unit)? = null
    ) {
        val tipo = registro.optString("tipo")
        val id = registro.optString("id")
        if (id.isEmpty()) return

        val base = item.text.toString()

        val atualizar = {
            item.text = if (ehFavorito(activity, tipo, id)) "★  $base" else base
        }
        atualizar()

        item.setOnLongClickListener {
            val adicionado = BibliotecaLocal(activity).favorito(registro)
            atualizar()
            aoAlterar?.invoke()
            android.widget.Toast.makeText(
                activity,
                if (adicionado) "Adicionado aos favoritos ★" else "Removido dos favoritos",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            true
        }
    }
}
