package com.alcanais.app

import android.os.Bundle
import android.widget.Toast
import org.json.JSONObject
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.TextView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : BaseActivity() {

    override val ajustarBarrasDoSistema: Boolean = false

    private val serverUrl: String
        get() = getSharedPreferences("AL_CANAIS", MODE_PRIVATE)
            .getString("server_url", "http://z1sv.site:80") ?: "http://z1sv.site:80"

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var txtPlayerStatus: TextView
    private var streamId = ""
    private var tipo = "live"
    private var streamUrl = ""

    private val handler = Handler(Looper.getMainLooper())
    private var tentativaReconexao = 0
    private val maxTentativas = 10
    private var ultimaPosicao = 0L
    private var reconexaoAgendada = false

    // progresso / continuar assistindo
    private var chaveProgresso = ""
    private var serieIdAtual = ""
    private var serieNomeAtual = ""
    private var nomeAtual = ""
    private var extensaoAtual = "mp4"
    private var iconeAtual = ""
    private var avisouRetomada = false

    private val salvarRunnable = object : Runnable {
        override fun run() {
            salvarProgressoAtual()
            handler.postDelayed(this, 10000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        txtPlayerStatus = findViewById(R.id.txtPlayerStatus)
        streamId = intent.getStringExtra("stream_id") ?: ""
        tipo = intent.getStringExtra("tipo") ?: "live"

        if (streamId.isEmpty()) {
            txtPlayerStatus.text = "Conteúdo não identificado."
            return
        }
        val nomeConteudo = intent.getStringExtra("canal_nome") ?: intent.getStringExtra("filme_nome") ?: "Conteúdo $streamId"
        val serieId = intent.getStringExtra("serie_id") ?: ""
        val serieNome = intent.getStringExtra("serie_nome") ?: ""
        val ehEpisodio = tipo == "series"
        serieIdAtual = serieId
        serieNomeAtual = serieNome
        nomeAtual = nomeConteudo
        extensaoAtual = intent.getStringExtra("extensao") ?: "mp4"
        iconeAtual = intent.getStringExtra("icone") ?: ""
        chaveProgresso = when (tipo) {
            "vod" -> "vod:$streamId"
            "series" -> "ep:$streamId"
            else -> ""
        }

        val registro = JSONObject().apply {
            put("id", streamId)
            put("tipo", if (ehEpisodio) "series_episode" else tipo)
            put("nome", if (ehEpisodio && serieNome.isNotEmpty()) "$serieNome • $nomeConteudo" else nomeConteudo)
            put("extensao", intent.getStringExtra("extensao") ?: "mp4")
            put("icone", intent.getStringExtra("icone") ?: "")
            if (ehEpisodio) {
                put("series_id", serieId)
                put("serie_nome", serieNome)
            }
        }
        if (ehEpisodio) {
            // Recentes guarda a SÉRIE (abre os capítulos), com o último episódio visto
            if (serieId.isNotEmpty()) {
                BibliotecaLocal(this).registrar(JSONObject().apply {
                    put("tipo", "series")
                    put("id", serieId)
                    put("series_id", serieId)
                    put("nome", serieNome.ifEmpty { nomeConteudo })
                    put("ultimo_episodio", nomeConteudo)
                })
            }
        } else {
            BibliotecaLocal(this).registrar(registro)
        }

        // Favorito do player: em episódio, favorita a SÉRIE (não o episódio)
        val favorito = if (ehEpisodio && serieId.isNotEmpty()) JSONObject().apply {
            put("tipo", "series")
            put("id", serieId)
            put("series_id", serieId)
            put("nome", serieNome.ifEmpty { nomeConteudo })
        } else registro

        // Pressione e segure OK sobre o vídeo para alternar Favoritos.
        playerView.setOnLongClickListener {
            val adicionado = BibliotecaLocal(this).favorito(favorito)
            Toast.makeText(this, if (adicionado) "Adicionado aos favoritos" else "Removido dos favoritos", Toast.LENGTH_SHORT).show()
            true
        }
        iniciarPlayer()
    }

    private fun iniciarPlayer() {
        val preferencias = getSharedPreferences("AL_CANAIS", MODE_PRIVATE)
        val usuario = preferencias.getString("username", "") ?: ""
        val senha = preferencias.getString("password", "") ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {
            txtPlayerStatus.text = "Login não encontrado."
            return
        }

        val extensao = intent.getStringExtra("extensao") ?: "mp4"
        streamUrl = when (tipo) {
            "vod" -> "$serverUrl/movie/$usuario/$senha/$streamId.$extensao"
            "series" -> "$serverUrl/series/$usuario/$senha/$streamId.$extensao"
            else -> "$serverUrl/live/$usuario/$senha/$streamId.ts"
        }

        liberarPlayer()
        player = criarExoPlayer(this).also { exo ->
            playerView.player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_BUFFERING -> {
                            txtPlayerStatus.visibility = View.VISIBLE
                            txtPlayerStatus.text = if (tentativaReconexao > 0) "Reconectando..." else "Carregando..."
                        }
                        Player.STATE_READY -> {
                            tentativaReconexao = 0
                            reconexaoAgendada = false
                            txtPlayerStatus.visibility = View.GONE
                        }
                        Player.STATE_ENDED -> {
                            if (tipo == "live") agendarReconexao()
                            else {
                                txtPlayerStatus.visibility = View.VISIBLE
                                txtPlayerStatus.text = "Reprodução encerrada."
                            }
                        }
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    if (tipo != "live") {
                        ultimaPosicao = player?.currentPosition ?: ultimaPosicao
                    }
                    agendarReconexao()
                }
            })
            val inicio = if (tipo == "live") 0L
                else if (ultimaPosicao > 0L) ultimaPosicao
                else posicaoSalva()
            if (inicio > 0L) {
                exo.setMediaItem(MediaItem.fromUri(streamUrl), inicio)
            } else {
                exo.setMediaItem(MediaItem.fromUri(streamUrl))
            }
            exo.prepare()
            exo.playWhenReady = true

            handler.removeCallbacks(salvarRunnable)
            if (chaveProgresso.isNotEmpty()) {
                handler.postDelayed(salvarRunnable, 10000L)
            }
        }
    }

    /** Posição para retomar (ms), ou 0 se começa do início. */
    private fun posicaoSalva(): Long {
        if (chaveProgresso.isEmpty()) return 0L
        val p = BibliotecaLocal(this).progresso(chaveProgresso) ?: return 0L
        val pos = p[0]
        val dur = p[1]
        if (pos < 15000L) return 0L
        if (dur > 0 && pos >= dur * 0.92) return 0L
        val inicio = (pos - 3000L).coerceAtLeast(0L)
        if (!avisouRetomada) {
            avisouRetomada = true
            val seg = inicio / 1000
            val texto = if (seg >= 3600) "%d:%02d:%02d".format(seg / 3600, (seg % 3600) / 60, seg % 60)
            else "%d:%02d".format(seg / 60, seg % 60)
            Toast.makeText(this, "Retomando de $texto", Toast.LENGTH_LONG).show()
        }
        return inicio
    }

    private fun salvarProgressoAtual() {
        if (chaveProgresso.isEmpty()) return
        val exo = player ?: return
        val pos = exo.currentPosition
        val dur = exo.duration
        if (dur <= 0L || pos <= 0L) return

        val bib = BibliotecaLocal(this)
        val ehEp = tipo == "series"

        if (pos >= dur * 0.92) {
            // terminou: sai do "continuar assistindo" e conta como assistido
            bib.limparProgresso(chaveProgresso)
            if (ehEp) {
                bib.marcarVisto(serieIdAtual, streamId, true)
            } else {
                bib.removerDe("continuar", "vod", streamId)
            }
            return
        }

        bib.salvarProgresso(chaveProgresso, pos, dur)

        if (pos > 15000L) {
            if (ehEp) {
                if (serieIdAtual.isNotEmpty()) {
                    bib.registrarEm("continuar", JSONObject().apply {
                        put("tipo", "series")
                        put("id", serieIdAtual)
                        put("series_id", serieIdAtual)
                        put("nome", serieNomeAtual.ifEmpty { nomeAtual })
                        put("episodio_id", streamId)
                        put("episodio_nome", nomeAtual)
                    })
                }
            } else {
                bib.registrarEm("continuar", JSONObject().apply {
                    put("tipo", "vod")
                    put("id", streamId)
                    put("nome", nomeAtual)
                    put("extensao", extensaoAtual)
                    put("icone", iconeAtual)
                })
            }
        }
    }

    private fun agendarReconexao() {
        if (reconexaoAgendada || isFinishing || isDestroyed) return
        if (tentativaReconexao >= maxTentativas) {
            txtPlayerStatus.visibility = View.VISIBLE
            txtPlayerStatus.text = "Sinal interrompido. Pressione voltar e tente novamente."
            return
        }
        tentativaReconexao++
        reconexaoAgendada = true
        txtPlayerStatus.visibility = View.VISIBLE
        txtPlayerStatus.text = "Reconectando... ($tentativaReconexao/$maxTentativas)"

        handler.postDelayed({
            reconexaoAgendada = false
            if (!isFinishing && !isDestroyed) iniciarPlayer()
        }, (2000L * tentativaReconexao).coerceAtMost(8000L))
    }

    private fun liberarPlayer() {
        playerView.player = null
        player?.release()
        player = null
    }

    override fun onStart() {
        super.onStart()
        if (player == null && streamId.isNotEmpty() && streamUrl.isNotEmpty()) {
            tentativaReconexao = 0
            iniciarPlayer()
        }
    }

    override fun onStop() {
        super.onStop()
        if (tipo != "live") {
            ultimaPosicao = player?.currentPosition ?: ultimaPosicao
        }
        salvarProgressoAtual()
        handler.removeCallbacksAndMessages(null)
        reconexaoAgendada = false
        liberarPlayer()
    }
}
