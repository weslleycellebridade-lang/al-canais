package com.alcanais.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class CanaisActivity : BaseActivity() {

    private val serverUrl: String
        get() {
            return getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            ).getString(
                "server_url",
                "http://z1sv.site:80"
            ) ?: "http://z1sv.site:80"
        }

    private lateinit var containerCategorias: LinearLayout
    private lateinit var containerCanais: LinearLayout

    private lateinit var txtStatusCanais: TextView
    private lateinit var txtMensagemCanais: TextView
    private lateinit var txtCanalSelecionado: TextView
    private lateinit var txtPlayerMiniStatus: TextView

    private lateinit var btnVoltar: TextView
    private lateinit var btnBuscarCanal: TextView

    private lateinit var playerViewMini: PlayerView

    private var miniPlayer: ExoPlayer? = null

    // Reconexão automática do mini player
    private val handlerMini = Handler(Looper.getMainLooper())
    private var tentativasMini = 0
    private val maxTentativasMini = 8

    private var streamIdSelecionado = ""
    private var nomeCanalSelecionado = ""

    // Guarda as Views selecionadas
    private var categoriaSelecionadaView: TextView? = null
    private var canalSelecionadoView: TextView? = null

    // =========================================================
    // DADOS DA LISTA ATUAL
    // =========================================================

    private data class Canal(
        val nome: String,
        val streamId: String
    )

    private val listaCanaisAtual =
        mutableListOf<Canal>()

    // =========================================================
    // ON CREATE
    // =========================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_canais)

        containerCategorias =
            findViewById(R.id.containerCategorias)

        containerCanais =
            findViewById(R.id.containerCanais)

        txtStatusCanais =
            findViewById(R.id.txtStatusCanais)

        txtMensagemCanais =
            findViewById(R.id.txtMensagemCanais)

        txtCanalSelecionado =
            findViewById(R.id.txtCanalSelecionado)

        txtPlayerMiniStatus =
            findViewById(R.id.txtPlayerMiniStatus)

        btnVoltar =
            findViewById(R.id.btnVoltar)

        btnBuscarCanal =
            findViewById(R.id.btnBuscarCanal)

        playerViewMini =
            findViewById(R.id.playerViewMini)

        btnVoltar.setOnClickListener {
            finish()
        }

        btnBuscarCanal.setOnClickListener {
            abrirBuscaCanal()
        }

        // FOCO VISÍVEL NO BOTÃO VOLTAR
        btnVoltar.setOnFocusChangeListener { view, temFoco ->

            val texto = view as TextView

            if (temFoco) {
                texto.background =
                    criarFundoItem("#F5B700")

                texto.setTextColor(Color.BLACK)
            } else {
                texto.background =
                    criarFundoItem("#162638")

                texto.setTextColor(Color.WHITE)
            }
        }

        // FOCO VISÍVEL NO BOTÃO BUSCAR
        btnBuscarCanal.setOnFocusChangeListener { view, temFoco ->

            val texto = view as TextView

            if (temFoco) {
                texto.background =
                    criarFundoItem("#F5B700")

                texto.setTextColor(Color.BLACK)
            } else {
                texto.background =
                    criarFundoItem("#162638")

                texto.setTextColor(Color.WHITE)
            }
        }

        prepararMiniPlayer()

        restaurarUltimoCanal()

        carregarCategorias()
    }

    // =========================================================
    // MINI PLAYER
    // =========================================================

    private fun prepararMiniPlayer() {

        miniPlayer =
            criarExoPlayer(this)

        playerViewMini.player =
            miniPlayer

        miniPlayer?.addListener(

            object : Player.Listener {

                override fun onPlaybackStateChanged(
                    playbackState: Int
                ) {

                    when (playbackState) {

                        Player.STATE_BUFFERING -> {

                            txtPlayerMiniStatus.visibility =
                                View.VISIBLE

                            txtPlayerMiniStatus.text =
                                "Carregando..."
                        }

                        Player.STATE_READY -> {

                            tentativasMini = 0

                            txtPlayerMiniStatus.visibility =
                                View.GONE
                        }

                        Player.STATE_ENDED -> {

                            reconectarMiniPlayer()
                        }
                    }
                }

                override fun onPlayerError(
                    error: PlaybackException
                ) {

                    reconectarMiniPlayer()
                }
            }
        )
    }

    // =========================================================
    // RECONEXÃO AUTOMÁTICA DO MINI PLAYER
    // =========================================================

    private fun reconectarMiniPlayer() {

        if (
            isFinishing ||
            isDestroyed ||
            streamIdSelecionado.isEmpty()
        ) {
            return
        }

        if (tentativasMini >= maxTentativasMini) {

            txtPlayerMiniStatus.visibility =
                View.VISIBLE

            txtPlayerMiniStatus.text =
                "Sinal interrompido. Selecione o canal novamente."

            return
        }

        tentativasMini++

        txtPlayerMiniStatus.visibility =
            View.VISIBLE

        txtPlayerMiniStatus.text =
            "Reconectando... ($tentativasMini/$maxTentativasMini)"

        handlerMini.removeCallbacksAndMessages(null)

        handlerMini.postDelayed(
            {
                if (
                    !isFinishing &&
                    !isDestroyed &&
                    streamIdSelecionado.isNotEmpty()
                ) {
                    reproduzirNoMiniPlayer(
                        streamIdSelecionado,
                        true
                    )
                }
            },
            (2000L * tentativasMini).coerceAtMost(8000L)
        )
    }

    // =========================================================
    // ÚLTIMO CANAL ASSISTIDO
    // =========================================================

    private fun salvarUltimoCanal(
        streamId: String,
        nome: String
    ) {

        getSharedPreferences(
            "AL_CANAIS",
            MODE_PRIVATE
        ).edit()
            .putString("ultimo_canal_id", streamId)
            .putString("ultimo_canal_nome", nome)
            .apply()
    }

    private fun restaurarUltimoCanal() {

        val prefs =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val id =
            prefs.getString("ultimo_canal_id", "") ?: ""

        val nome =
            prefs.getString("ultimo_canal_nome", "") ?: ""

        if (id.isEmpty()) return

        // O onResume inicia a reprodução deste canal
        streamIdSelecionado = id
        nomeCanalSelecionado = nome

        txtCanalSelecionado.text =
            nome
    }

    // =========================================================
    // CARREGAR CATEGORIAS
    // =========================================================

    private fun carregarCategorias() {

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            preferencias.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            preferencias.getString(
                "password",
                ""
            ) ?: ""

        if (
            usuario.isEmpty() ||
            senha.isEmpty()
        ) {

            txtStatusCanais.text =
                "Dados de acesso não encontrados."

            return
        }

        txtStatusCanais.setTextColor(
            Color.parseColor("#9EADBF")
        )

        txtStatusCanais.text =
            "Carregando categorias..."

        thread {

            var conexao: HttpURLConnection? =
                null

            try {

                val usuarioCodificado =
                    URLEncoder.encode(
                        usuario,
                        "UTF-8"
                    )

                val senhaCodificada =
                    URLEncoder.encode(
                        senha,
                        "UTF-8"
                    )

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$usuarioCodificado" +
                            "&password=$senhaCodificada" +
                            "&action=get_live_categories"

                conexao =
                    URL(endereco)
                        .openConnection() as HttpURLConnection

                conexao.requestMethod =
                    "GET"

                conexao.connectTimeout =
                    15000

                conexao.readTimeout =
                    15000

                val codigo =
                    conexao.responseCode

                if (
                    codigo !=
                    HttpURLConnection.HTTP_OK
                ) {

                    mostrarErro(
                        "Erro do servidor: $codigo"
                    )

                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                val categorias =
                    JSONArray(resposta)

                runOnUiThread {

                    containerCategorias
                        .removeAllViews()
                    adicionarCategoriaBiblioteca("★ Favoritos", "favoritos", "live")
                    adicionarCategoriaBiblioteca("◷ Recentes", "recentes", "live")


                    categoriaSelecionadaView = null

                    if (
                        categorias.length() == 0
                    ) {

                        txtStatusCanais.text =
                            "Nenhuma categoria encontrada."

                        return@runOnUiThread
                    }

                    txtStatusCanais.text =
                        "${categorias.length()} categorias encontradas"

                    for (
                    i in 0 until categorias.length()
                    ) {

                        val categoria =
                            categorias
                                .getJSONObject(i)

                        val nome =
                            categoria.optString(
                                "category_name",
                                "Categoria"
                            )

                        val id =
                            categoria.optString(
                                "category_id",
                                ""
                            )

                        adicionarCategoria(
                            nome,
                            id
                        )
                    }

                    // Na TV, posiciona o cursor na primeira categoria
                    if (containerCategorias.childCount > 0) {
                        containerCategorias
                            .getChildAt(0)
                            .requestFocus()
                    }
                }

            } catch (
                e: Exception
            ) {

                e.printStackTrace()

                mostrarErro(
                    "Não foi possível carregar as categorias."
                )

            } finally {

                conexao?.disconnect()
            }
        }
    }

    // =========================================================
    // ADICIONAR CATEGORIA
    // =========================================================

    private fun adicionarCategoria(
        nome: String,
        id: String
    ) {

        val item =
            TextView(this)

        item.text =
            nome

        item.textSize =
            13f

        item.setTextColor(
            Color.WHITE
        )

        item.gravity =
            Gravity.CENTER_VERTICAL

        item.setPadding(
            dp(12),
            0,
            dp(8),
            0
        )

        item.background =
            criarFundoItem(
                "#162638"
            )

        val parametros =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(36)
            )

        parametros.setMargins(
            0,
            0,
            0,
            dp(3)
        )

        item.layoutParams =
            parametros

        item.isClickable =
            true

        item.isFocusable =
            true

        // =====================================================
        // FOCO DO CONTROLE REMOTO
        // =====================================================

        item.setOnFocusChangeListener { view, temFoco ->

            val texto =
                view as TextView

            if (temFoco) {

                // AMARELO = posição atual do controle
                texto.background =
                    criarFundoItem(
                        "#F5B700"
                    )

                texto.setTextColor(
                    Color.BLACK
                )

            } else {

                // Se esta categoria já foi selecionada,
                // permanece azul.
                if (categoriaSelecionadaView === texto) {

                    texto.background =
                        criarFundoItem(
                            "#086BC1"
                        )

                    texto.setTextColor(
                        Color.WHITE
                    )

                } else {

                    texto.background =
                        criarFundoItem(
                            "#162638"
                        )

                    texto.setTextColor(
                        Color.WHITE
                    )
                }
            }
        }

        item.setOnClickListener {

            categoriaSelecionadaView =
                item

            destacarCategoria(
                item
            )

            carregarCanais(
                id,
                nome
            )
        }

        containerCategorias
            .addView(item)
    }

    // =========================================================
    // DESTACAR CATEGORIA
    // =========================================================

    private fun destacarCategoria(
        selecionado: TextView
    ) {

        categoriaSelecionadaView =
            selecionado

        for (
        i in 0 until
                containerCategorias.childCount
        ) {

            val view =
                containerCategorias
                    .getChildAt(i)

            if (
                view is TextView
            ) {

                if (view.hasFocus()) {

                    view.background =
                        criarFundoItem(
                            "#F5B700"
                        )

                    view.setTextColor(
                        Color.BLACK
                    )

                } else {

                    view.background =
                        criarFundoItem(
                            "#162638"
                        )

                    view.setTextColor(
                        Color.WHITE
                    )
                }
            }
        }

        // Se ainda estiver com foco, mantém amarelo.
        // Quando o foco sair, o listener mudará para azul.
        if (selecionado.hasFocus()) {

            selecionado.background =
                criarFundoItem(
                    "#F5B700"
                )

            selecionado.setTextColor(
                Color.BLACK
            )

        } else {

            selecionado.background =
                criarFundoItem(
                    "#086BC1"
                )

            selecionado.setTextColor(
                Color.WHITE
            )
        }
    }

    // =========================================================
    // CARREGAR CANAIS
    // =========================================================

    private fun carregarCanais(
        categoryId: String,
        categoryName: String
    ) {

        containerCanais
            .removeAllViews()

        canalSelecionadoView = null

        listaCanaisAtual.clear()

        txtMensagemCanais.visibility =
            View.VISIBLE

        txtMensagemCanais.text =
            "Carregando $categoryName..."

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            preferencias.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            preferencias.getString(
                "password",
                ""
            ) ?: ""

        if (
            usuario.isEmpty() ||
            senha.isEmpty()
        ) {

            txtMensagemCanais.text =
                "Login não encontrado."

            return
        }

        thread {

            var conexao: HttpURLConnection? =
                null

            try {

                val usuarioCodificado =
                    URLEncoder.encode(
                        usuario,
                        "UTF-8"
                    )

                val senhaCodificada =
                    URLEncoder.encode(
                        senha,
                        "UTF-8"
                    )

                val categoriaCodificada =
                    URLEncoder.encode(
                        categoryId,
                        "UTF-8"
                    )

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$usuarioCodificado" +
                            "&password=$senhaCodificada" +
                            "&action=get_live_streams" +
                            "&category_id=$categoriaCodificada"

                conexao =
                    URL(endereco)
                        .openConnection() as HttpURLConnection

                conexao.requestMethod =
                    "GET"

                conexao.connectTimeout =
                    15000

                conexao.readTimeout =
                    15000

                val codigo =
                    conexao.responseCode

                if (
                    codigo !=
                    HttpURLConnection.HTTP_OK
                ) {

                    runOnUiThread {

                        txtMensagemCanais.visibility =
                            View.VISIBLE

                        txtMensagemCanais.text =
                            "Erro ao carregar canais: $codigo"
                    }

                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                val canais =
                    JSONArray(resposta)

                runOnUiThread {

                    containerCanais
                        .removeAllViews()

                    listaCanaisAtual.clear()

                    canalSelecionadoView = null

                    if (
                        canais.length() == 0
                    ) {

                        txtMensagemCanais.visibility =
                            View.VISIBLE

                        txtMensagemCanais.text =
                            "Nenhum canal encontrado."

                        return@runOnUiThread
                    }

                    txtMensagemCanais.visibility =
                        View.GONE

                    txtStatusCanais.text =
                        "$categoryName • ${canais.length()} canais"

                    for (
                    i in 0 until canais.length()
                    ) {

                        val canal =
                            canais
                                .getJSONObject(i)

                        val nome =
                            canal.optString(
                                "name",
                                "Canal"
                            )

                        val streamId =
                            canal.optString(
                                "stream_id",
                                ""
                            )

                        listaCanaisAtual.add(
                            Canal(
                                nome,
                                streamId
                            )
                        )

                        adicionarCanal(
                            nome,
                            streamId
                        )
                    }
                }

            } catch (
                e: Exception
            ) {

                e.printStackTrace()

                runOnUiThread {

                    txtMensagemCanais.visibility =
                        View.VISIBLE

                    txtMensagemCanais.text =
                        "Não foi possível carregar os canais."
                }

            } finally {

                conexao?.disconnect()
            }
        }
    }

    // =========================================================
    // ADICIONAR CANAL
    // =========================================================

    private fun adicionarCanal(
        nome: String,
        streamId: String
    ) {

        val item =
            TextView(this)

        item.text =
            nome

        item.textSize =
            13f

        item.setTextColor(
            Color.WHITE
        )

        item.gravity =
            Gravity.CENTER_VERTICAL

        item.setPadding(
            dp(12),
            0,
            dp(8),
            0
        )

        item.background =
            criarFundoItem(
                "#162638"
            )

        val parametros =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(42)
            )

        parametros.setMargins(
            0,
            0,
            0,
            dp(4)
        )

        item.layoutParams =
            parametros

        item.isClickable =
            true

        item.isFocusable =
            true

        // =====================================================
        // FOCO DO CONTROLE REMOTO
        // =====================================================

        item.setOnFocusChangeListener { view, temFoco ->

            val texto =
                view as TextView

            if (temFoco) {

                // AMARELO = posição atual do controle
                texto.background =
                    criarFundoItem(
                        "#F5B700"
                    )

                texto.setTextColor(
                    Color.BLACK
                )

            } else {

                // Canal que já está tocando continua azul
                if (canalSelecionadoView === texto) {

                    texto.background =
                        criarFundoItem(
                            "#086BC1"
                        )

                    texto.setTextColor(
                        Color.WHITE
                    )

                } else {

                    texto.background =
                        criarFundoItem(
                            "#162638"
                        )

                    texto.setTextColor(
                        Color.WHITE
                    )
                }
            }
        }

        item.setOnClickListener {

            // SEGUNDO OK NO MESMO CANAL
            if (
                streamIdSelecionado == streamId &&
                streamIdSelecionado.isNotEmpty()
            ) {

                abrirTelaCheia(
                    streamId,
                    nome
                )

                return@setOnClickListener
            }

            // PRIMEIRO OK
            streamIdSelecionado =
                streamId

            nomeCanalSelecionado =
                nome

            canalSelecionadoView =
                item

            destacarCanal(
                item
            )

            txtCanalSelecionado.text =
                nome

            salvarUltimoCanal(
                streamId,
                nome
            )

            reproduzirNoMiniPlayer(
                streamId
            )
        }

        containerCanais
            .addView(item)
    }

    // =========================================================
    // DESTACAR CANAL
    // =========================================================

    private fun destacarCanal(
        selecionado: TextView
    ) {

        canalSelecionadoView =
            selecionado

        for (
        i in 0 until
                containerCanais.childCount
        ) {

            val view =
                containerCanais
                    .getChildAt(i)

            if (
                view is TextView
            ) {

                if (view.hasFocus()) {

                    view.background =
                        criarFundoItem(
                            "#F5B700"
                        )

                    view.setTextColor(
                        Color.BLACK
                    )

                } else {

                    view.background =
                        criarFundoItem(
                            "#162638"
                        )

                    view.setTextColor(
                        Color.WHITE
                    )
                }
            }
        }

        if (selecionado.hasFocus()) {

            selecionado.background =
                criarFundoItem(
                    "#F5B700"
                )

            selecionado.setTextColor(
                Color.BLACK
            )

        } else {

            selecionado.background =
                criarFundoItem(
                    "#086BC1"
                )

            selecionado.setTextColor(
                Color.WHITE
            )
        }
    }

    // =========================================================
    // BUSCAR CANAL
    // =========================================================

    private fun abrirBuscaCanal() {

        if (
            listaCanaisAtual.isEmpty()
        ) {

            Toast.makeText(
                this,
                "Selecione uma categoria primeiro.",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val campoBusca =
            EditText(this).apply {

                hint =
                    "Digite o nome do canal"

                setSingleLine(true)

                setTextColor(
                    Color.BLACK
                )

                setHintTextColor(
                    Color.parseColor(
                        "#777777"
                    )
                )

                setPadding(
                    dp(16),
                    dp(10),
                    dp(16),
                    dp(10)
                )
            }

        val dialogo =
            AlertDialog.Builder(this)
                .setTitle(
                    "Buscar canal"
                )
                .setView(
                    campoBusca
                )
                .setPositiveButton(
                    "BUSCAR",
                    null
                )
                .setNegativeButton(
                    "CANCELAR",
                    null
                )
                .setNeutralButton(
                    "MOSTRAR TODOS",
                    null
                )
                .create()

        dialogo.setOnShowListener {

            dialogo.getButton(
                AlertDialog.BUTTON_POSITIVE
            ).setOnClickListener {

                val termo =
                    campoBusca.text
                        .toString()
                        .trim()

                if (
                    termo.isEmpty()
                ) {

                    mostrarTodosCanais()

                    dialogo.dismiss()

                    return@setOnClickListener
                }

                filtrarCanais(
                    termo
                )

                dialogo.dismiss()
            }

            dialogo.getButton(
                AlertDialog.BUTTON_NEUTRAL
            ).setOnClickListener {

                mostrarTodosCanais()

                dialogo.dismiss()
            }
        }

        dialogo.show()

        campoBusca.requestFocus()

        dialogo.window?.setSoftInputMode(
            android.view.WindowManager.LayoutParams
                .SOFT_INPUT_STATE_ALWAYS_VISIBLE
        )
    }

    // =========================================================
    // FILTRAR CANAIS
    // =========================================================

    private fun filtrarCanais(
        termo: String
    ) {

        containerCanais
            .removeAllViews()

        canalSelecionadoView = null

        val resultado =
            listaCanaisAtual.filter {

                it.nome.contains(
                    termo,
                    ignoreCase = true
                )
            }

        if (
            resultado.isEmpty()
        ) {

            txtMensagemCanais.visibility =
                View.VISIBLE

            txtMensagemCanais.text =
                "Nenhum canal encontrado para \"$termo\"."

            txtStatusCanais.text =
                "Busca sem resultados"

            return
        }

        txtMensagemCanais.visibility =
            View.GONE

        resultado.forEach {
                canal ->

            adicionarCanal(
                canal.nome,
                canal.streamId
            )
        }

        txtStatusCanais.text =
            "${resultado.size} resultado(s) para \"$termo\""

        if (containerCanais.childCount > 0) {
            containerCanais
                .getChildAt(0)
                .requestFocus()
        }
    }

    // =========================================================
    // MOSTRAR TODOS OS CANAIS
    // =========================================================

    private fun mostrarTodosCanais() {

        containerCanais
            .removeAllViews()

        canalSelecionadoView = null

        if (
            listaCanaisAtual.isEmpty()
        ) {

            txtMensagemCanais.visibility =
                View.VISIBLE

            txtMensagemCanais.text =
                "Nenhum canal carregado."

            return
        }

        txtMensagemCanais.visibility =
            View.GONE

        listaCanaisAtual.forEach {
                canal ->

            adicionarCanal(
                canal.nome,
                canal.streamId
            )
        }

        txtStatusCanais.text =
            "${listaCanaisAtual.size} canais"

        if (containerCanais.childCount > 0) {
            containerCanais
                .getChildAt(0)
                .requestFocus()
        }
    }

    // =========================================================
    // REPRODUZIR NO MINI PLAYER
    // =========================================================

    private fun reproduzirNoMiniPlayer(
        streamId: String,
        reconexao: Boolean = false
    ) {

        if (!reconexao) {
            tentativasMini = 0
            handlerMini.removeCallbacksAndMessages(null)
        }

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            preferencias.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            preferencias.getString(
                "password",
                ""
            ) ?: ""

        if (
            usuario.isEmpty() ||
            senha.isEmpty()
        ) {

            txtPlayerMiniStatus.visibility =
                View.VISIBLE

            txtPlayerMiniStatus.text =
                "Login não encontrado."

            return
        }

        txtPlayerMiniStatus.visibility =
            View.VISIBLE

        txtPlayerMiniStatus.text =
            if (reconexao) "Reconectando..." else "Carregando..."

        val streamUrl =
            "$serverUrl/live/$usuario/$senha/$streamId.ts"

        val mediaItem =
            MediaItem.fromUri(
                streamUrl
            )

        miniPlayer?.apply {

            stop()

            clearMediaItems()

            setMediaItem(
                mediaItem
            )

            prepare()

            playWhenReady =
                true
        }
    }

    // =========================================================
    // ABRIR TELA CHEIA
    // =========================================================

    private fun abrirTelaCheia(
        streamId: String,
        nome: String
    ) {

        miniPlayer?.pause()

        salvarUltimoCanal(
            streamId,
            nome
        )

        val intent =
            Intent(
                this,
                PlayerActivity::class.java
            )

        intent.putExtra(
            "stream_id",
            streamId
        )

        intent.putExtra(
            "canal_nome",
            nome
        )

        intent.putExtra(
            "tipo",
            "live"
        )

        startActivity(
            intent
        )
    }

    // =========================================================
    // FUNDO DOS ITENS
    // =========================================================

    private fun criarFundoItem(
        cor: String
    ): GradientDrawable {

        return GradientDrawable()
            .apply {

                shape =
                    GradientDrawable.RECTANGLE

                setColor(
                    Color.parseColor(
                        cor
                    )
                )

                cornerRadius =
                    dp(6).toFloat()
            }
    }

    // =========================================================
    // ERROS
    // =========================================================

    private fun mostrarErro(
        mensagem: String
    ) {

        runOnUiThread {

            txtStatusCanais
                .setTextColor(
                    Color.parseColor(
                        "#FF5C68"
                    )
                )

            txtStatusCanais.text =
                mensagem
        }
    }

    // =========================================================
    // CICLO DE VIDA DO PLAYER
    // =========================================================

    override fun onResume() {
        super.onResume()

        if (
            streamIdSelecionado.isNotEmpty() &&
            miniPlayer != null
        ) {

            reproduzirNoMiniPlayer(
                streamIdSelecionado
            )
        }
    }

    override fun onStop() {
        super.onStop()

        handlerMini.removeCallbacksAndMessages(null)

        miniPlayer?.stop()
    }

    override fun onDestroy() {
        super.onDestroy()

        handlerMini.removeCallbacksAndMessages(null)

        playerViewMini.player =
            null

        miniPlayer?.release()

        miniPlayer =
            null
    }

    // =========================================================
    // DP
    // =========================================================

    private fun dp(
        valor: Int
    ): Int {

        return (
                valor *
                        resources
                            .displayMetrics
                            .density
                ).toInt()
    }

    private fun adicionarCategoriaBiblioteca(titulo: String, secao: String, tipo: String) {
        val item = TextView(this).apply {
            text = titulo
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(18, 18, 18, 18)
            isFocusable = true
            setOnClickListener {
                startActivity(Intent(this@CanaisActivity, BibliotecaActivity::class.java).apply {
                    putExtra("tipo_secao", tipo)
                    putExtra("secao_inicial", secao)
                })
            }
        }
        containerCategorias.addView(item, 0)
    }
}