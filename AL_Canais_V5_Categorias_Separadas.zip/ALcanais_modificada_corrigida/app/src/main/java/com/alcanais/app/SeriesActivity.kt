package com.alcanais.app

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class SeriesActivity : BaseActivity() {

    private val serverUrl: String
        get() {
            return getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            ).getString(
                "server_url",
                "http://z1sv.site:80"
            ) ?: "http://z1sv.site:80"
        }

    private lateinit var containerCategorias: LinearLayout
    private lateinit var containerSeries: LinearLayout

    private lateinit var txtStatus: TextView
    private lateinit var txtMensagemSeries: TextView

    private lateinit var btnVoltar: TextView
    private lateinit var btnBuscar: TextView

    private var categoriaSelecionada: TextView? = null

    // Séries da categoria aberta (usada pela busca)
    private val listaSeries = mutableListOf<JSONObject>()

    // Todas as séries do servidor (carregadas só uma vez, na primeira busca)
    private var todasSeries: List<JSONObject>? = null

    private val limiteResultados = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_series)

        // COMPONENTES
        containerCategorias =
            findViewById(R.id.containerCategoriasSeries)

        containerSeries =
            findViewById(R.id.containerSeries)

        txtStatus =
            findViewById(R.id.txtStatusSeries)

        txtMensagemSeries =
            findViewById(R.id.txtMensagemSeries)

        btnVoltar =
            findViewById(R.id.btnVoltarSeries)

        btnBuscar =
            findViewById(R.id.btnBuscarSerie)

        // VOLTAR
        btnVoltar.setOnClickListener {
            finish()
        }

        // BUSCAR
        btnBuscar.setOnClickListener {
            abrirBusca()
        }

        configurarFocoCabecalho(btnVoltar)
        configurarFocoCabecalho(btnBuscar)

        carregarCategorias()
    }

    // =========================================================
    // CARREGAR CATEGORIAS
    // =========================================================

    private fun carregarCategorias() {

        val prefs =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            prefs.getString("username", "") ?: ""

        val senha =
            prefs.getString("password", "") ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {

            txtStatus.text =
                "Login não encontrado."

            return
        }

        txtStatus.setTextColor(
            Color.parseColor("#9EADBF")
        )

        txtStatus.text =
            "Carregando categorias..."

        thread {

            var conexao: HttpURLConnection? = null

            try {

                val u =
                    URLEncoder.encode(
                        usuario,
                        "UTF-8"
                    )

                val s =
                    URLEncoder.encode(
                        senha,
                        "UTF-8"
                    )

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$u" +
                            "&password=$s" +
                            "&action=get_series_categories"

                conexao =
                    URL(endereco)
                        .openConnection() as HttpURLConnection

                conexao.requestMethod = "GET"
                conexao.connectTimeout = 15000
                conexao.readTimeout = 15000

                val codigo =
                    conexao.responseCode

                if (codigo != HttpURLConnection.HTTP_OK) {

                    mostrarErro(
                        "Erro do servidor: $codigo"
                    )

                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                val categorias =
                    JSONArray(resposta)

                runOnUiThread {

                    containerCategorias.removeAllViews()
                    adicionarCategoriaBiblioteca("★ Favoritos", "favoritos", "series")
                    adicionarCategoriaBiblioteca("◷ Recentes", "recentes", "series")


                    if (categorias.length() == 0) {

                        txtStatus.text =
                            "Nenhuma categoria encontrada."

                        return@runOnUiThread
                    }

                    txtStatus.text =
                        "${categorias.length()} categorias encontradas"

                    for (i in 0 until categorias.length()) {

                        val categoria =
                            categorias.getJSONObject(i)

                        val nome =
                            categoria.optString(
                                "category_name",
                                "Categoria"
                            )

                        val id =
                            categoria.optString(
                                "category_id",
                                ""
                            )

                        adicionarCategoria(
                            nome,
                            id
                        )
                    }

                    // PRIMEIRO FOCO
                    if (containerCategorias.childCount > 0) {

                        containerCategorias
                            .getChildAt(0)
                            .post {

                                containerCategorias
                                    .getChildAt(0)
                                    .requestFocus()
                            }
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()

                mostrarErro(
                    "Não foi possível carregar as categorias."
                )

            } finally {

                conexao?.disconnect()
            }
        }
    }

    // =========================================================
    // ADICIONAR CATEGORIA
    // =========================================================

    private fun adicionarCategoria(
        nome: String,
        id: String
    ) {

        val item =
            TextView(this)

        item.text =
            "▶  $nome"

        item.textSize =
            13f

        item.setTextColor(
            Color.WHITE
        )

        item.gravity =
            Gravity.CENTER_VERTICAL

        item.setPadding(
            dp(12),
            0,
            dp(8),
            0
        )

        item.background =
            criarFundoItem(
                "#162638"
            )

        val parametros =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(46)
            )

        parametros.setMargins(
            0,
            0,
            0,
            dp(5)
        )

        item.layoutParams =
            parametros

        item.isClickable = true
        item.isFocusable = true

        // FOCO VISUAL
        item.setOnFocusChangeListener { _, temFoco ->

            if (temFoco) {

                item.background =
                    criarFundoComBorda(
                        "#086BC1",
                        "#FFD600"
                    )

                item.scaleX = 1.02f
                item.scaleY = 1.02f

            } else {

                if (item == categoriaSelecionada) {

                    item.background =
                        criarFundoItem(
                            "#086BC1"
                        )

                } else {

                    item.background =
                        criarFundoItem(
                            "#162638"
                        )
                }

                item.scaleX = 1f
                item.scaleY = 1f
            }
        }

        item.setOnClickListener {

            destacarCategoria(item)

            carregarSeries(
                id,
                nome
            )
        }

        containerCategorias.addView(item)
    }

    // =========================================================
    // DESTACAR CATEGORIA
    // =========================================================

    private fun destacarCategoria(
        selecionada: TextView
    ) {

        categoriaSelecionada?.background =
            criarFundoItem(
                "#162638"
            )

        selecionada.background =
            criarFundoItem(
                "#086BC1"
            )

        categoriaSelecionada =
            selecionada
    }

    // =========================================================
    // CARREGAR SÉRIES
    // =========================================================

    private fun carregarSeries(
        categoriaId: String,
        categoriaNome: String
    ) {

        val prefs =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            prefs.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            prefs.getString(
                "password",
                ""
            ) ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {

            txtMensagemSeries.text =
                "Login não encontrado."

            return
        }

        containerSeries.removeAllViews()
        listaSeries.clear()

        txtMensagemSeries.visibility =
            View.VISIBLE

        txtMensagemSeries.text =
            "Carregando séries..."

        txtStatus.text =
            "$categoriaNome • carregando..."

        thread {

            var conexao: HttpURLConnection? = null

            try {

                val u =
                    URLEncoder.encode(
                        usuario,
                        "UTF-8"
                    )

                val s =
                    URLEncoder.encode(
                        senha,
                        "UTF-8"
                    )

                val c =
                    URLEncoder.encode(
                        categoriaId,
                        "UTF-8"
                    )

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$u" +
                            "&password=$s" +
                            "&action=get_series" +
                            "&category_id=$c"

                conexao =
                    URL(endereco)
                        .openConnection() as HttpURLConnection

                conexao.requestMethod = "GET"
                conexao.connectTimeout = 15000
                conexao.readTimeout = 15000

                val codigo =
                    conexao.responseCode

                if (codigo != HttpURLConnection.HTTP_OK) {

                    runOnUiThread {

                        txtMensagemSeries.text =
                            "Erro do servidor: $codigo"
                    }

                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                val series =
                    JSONArray(resposta)

                runOnUiThread {

                    containerSeries.removeAllViews()

                    if (series.length() == 0) {

                        txtMensagemSeries.visibility =
                            View.VISIBLE

                        txtMensagemSeries.text =
                            "Nenhuma série encontrada."

                        txtStatus.text =
                            "$categoriaNome • 0 séries"

                        return@runOnUiThread
                    }

                    txtMensagemSeries.visibility =
                        View.GONE

                    txtStatus.text =
                        "$categoriaNome • ${series.length()} séries"

                    for (i in 0 until series.length()) {

                        val serie =
                            series.getJSONObject(i)

                        val nome =
                            serie.optString(
                                "name",
                                "Série"
                            )

                        val seriesId =
                            serie.optString(
                                "series_id",
                                ""
                            )

                        listaSeries.add(serie)

                        adicionarSerie(
                            nome,
                            seriesId
                        )
                    }

                    // FOCO VAI PARA PRIMEIRA SÉRIE
                    if (containerSeries.childCount > 0) {

                        containerSeries
                            .getChildAt(0)
                            .post {

                                containerSeries
                                    .getChildAt(0)
                                    .requestFocus()
                            }
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()

                runOnUiThread {

                    txtMensagemSeries.visibility =
                        View.VISIBLE

                    txtMensagemSeries.text =
                        "Não foi possível carregar as séries."
                }

            } finally {

                conexao?.disconnect()
            }
        }
    }

    // =========================================================
    // ADICIONAR SÉRIE
    // =========================================================

    private fun adicionarSerie(
        nome: String,
        seriesId: String
    ) {

        val item =
            TextView(this)

        item.text =
            "▶  $nome"

        item.textSize =
            14f

        item.setTextColor(
            Color.WHITE
        )

        item.gravity =
            Gravity.CENTER_VERTICAL

        item.setPadding(
            dp(16),
            0,
            dp(12),
            0
        )

        item.background =
            criarFundoItem(
                "#162638"
            )

        val parametros =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            )

        parametros.setMargins(
            0,
            0,
            0,
            dp(5)
        )

        item.layoutParams =
            parametros

        item.isClickable = true
        item.isFocusable = true

        // FOCO VISUAL PARA TV
        item.setOnFocusChangeListener { _, temFoco ->

            if (temFoco) {

                item.background =
                    criarFundoComBorda(
                        "#086BC1",
                        "#FFD600"
                    )

                item.scaleX = 1.01f
                item.scaleY = 1.04f

            } else {

                item.background =
                    criarFundoItem(
                        "#162638"
                    )

                item.scaleX = 1f
                item.scaleY = 1f
            }
        }

        FavUi.ligar(
            this,
            item,
            org.json.JSONObject().apply {
                put("tipo", "series")
                put("id", seriesId)
                put("series_id", seriesId)
                put("nome", nome)
            }
        )

        // OK NA SÉRIE = ABRE EPISÓDIOS
        item.setOnClickListener {

            if (seriesId.isNotEmpty()) {

                abrirEpisodios(
                    seriesId,
                    nome
                )
            }
        }

        containerSeries.addView(item)
    }

    // =========================================================
    // ABRIR EPISÓDIOS
    // =========================================================

    private fun abrirEpisodios(
        seriesId: String,
        nome: String
    ) {

        val intent =
            Intent(
                this,
                EpisodiosActivity::class.java
            )

        intent.putExtra(
            "series_id",
            seriesId
        )

        intent.putExtra(
            "serie_nome",
            nome
        )

        startActivity(intent)
    }

    // =========================================================
    // BUSCAR
    // =========================================================

    private fun abrirBusca() {

        val campoBusca = EditText(this)

        campoBusca.hint = "Digite o nome da série"
        campoBusca.setSingleLine(true)
        campoBusca.imeOptions = EditorInfo.IME_ACTION_SEARCH

        val container = LinearLayout(this)

        container.orientation = LinearLayout.VERTICAL

        container.setPadding(
            dp(20),
            dp(8),
            dp(20),
            0
        )

        container.addView(campoBusca)

        val dialogo =
            AlertDialog.Builder(this)
                .setTitle("Buscar em todas as séries")
                .setView(container)
                .setPositiveButton("BUSCAR", null)
                .setNeutralButton("LIMPAR", null)
                .setNegativeButton("CANCELAR", null)
                .create()

        dialogo.setOnShowListener {

            val botaoBuscar =
                dialogo.getButton(AlertDialog.BUTTON_POSITIVE)

            val botaoLimpar =
                dialogo.getButton(AlertDialog.BUTTON_NEUTRAL)

            val executarBusca: () -> Unit = {

                val termo =
                    campoBusca.text.toString().trim()

                if (termo.isEmpty()) {

                    campoBusca.error =
                        "Digite o nome da série"

                } else {

                    buscarEmTodasSeries(termo)

                    dialogo.dismiss()
                }
            }

            botaoBuscar.setOnClickListener {
                executarBusca()
            }

            // LIMPAR = volta para a lista da categoria aberta
            botaoLimpar.setOnClickListener {

                if (listaSeries.isEmpty()) {

                    containerSeries.removeAllViews()

                    txtMensagemSeries.visibility = View.VISIBLE

                    txtMensagemSeries.text =
                        "Selecione uma categoria"

                } else {

                    filtrarSeries("")
                }

                dialogo.dismiss()
            }

            campoBusca.setOnEditorActionListener { _, acao, _ ->

                if (acao == EditorInfo.IME_ACTION_SEARCH) {

                    executarBusca()

                    true

                } else {

                    false
                }
            }

            campoBusca.requestFocus()
        }

        dialogo.show()
    }

    // =========================================================
    // BUSCAR EM TODAS AS SÉRIES
    // =========================================================

    private fun buscarEmTodasSeries(
        termo: String
    ) {

        val prefs =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            prefs.getString("username", "") ?: ""

        val senha =
            prefs.getString("password", "") ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {

            txtStatus.text = "Login não encontrado."

            return
        }

        containerSeries.removeAllViews()

        txtMensagemSeries.visibility = View.VISIBLE

        txtMensagemSeries.text =
            "Buscando \"$termo\" em todas as séries..."

        thread {

            var conexao: HttpURLConnection? = null

            try {

                var base = todasSeries

                if (base == null) {

                    val u =
                        URLEncoder.encode(usuario, "UTF-8")

                    val s =
                        URLEncoder.encode(senha, "UTF-8")

                    val endereco =
                        "$serverUrl/player_api.php" +
                                "?username=$u" +
                                "&password=$s" +
                                "&action=get_series"

                    conexao =
                        URL(endereco)
                            .openConnection() as HttpURLConnection

                    conexao.requestMethod = "GET"
                    conexao.connectTimeout = 20000
                    conexao.readTimeout = 60000

                    val codigo = conexao.responseCode

                    if (codigo != HttpURLConnection.HTTP_OK) {

                        runOnUiThread {

                            txtMensagemSeries.text =
                                "Erro do servidor: $codigo"
                        }

                        return@thread
                    }

                    val resposta =
                        conexao.inputStream
                            .bufferedReader()
                            .use {
                                it.readText()
                            }

                    val array = JSONArray(resposta)

                    val lista = ArrayList<JSONObject>(array.length())

                    for (i in 0 until array.length()) {

                        lista.add(array.getJSONObject(i))
                    }

                    todasSeries = lista

                    base = lista
                }

                val baseFinal: List<JSONObject> =
                    base ?: emptyList()

                val encontradas =
                    baseFinal.filter {

                        it.optString("name", "")
                            .contains(
                                termo,
                                ignoreCase = true
                            )
                    }

                runOnUiThread {

                    mostrarResultadosSeries(
                        encontradas,
                        termo
                    )
                }

            } catch (e: Exception) {

                e.printStackTrace()

                runOnUiThread {

                    txtMensagemSeries.visibility = View.VISIBLE

                    txtMensagemSeries.text =
                        "Não foi possível buscar. Verifique a conexão."
                }

            } finally {

                conexao?.disconnect()
            }
        }
    }

    private fun mostrarResultadosSeries(
        encontradas: List<JSONObject>,
        termo: String
    ) {

        containerSeries.removeAllViews()

        if (encontradas.isEmpty()) {

            txtMensagemSeries.visibility = View.VISIBLE

            txtMensagemSeries.text =
                "Nenhuma série encontrada para \"$termo\"."

            txtStatus.text = "0 série(s) encontrada(s)"

            return
        }

        txtMensagemSeries.visibility = View.GONE

        for (serie in encontradas.take(limiteResultados)) {

            adicionarSerie(
                serie.optString("name", "Série"),
                serie.optString("series_id", "")
            )
        }

        txtStatus.text =
            if (encontradas.size > limiteResultados) {
                "Mostrando $limiteResultados de ${encontradas.size} • refine a busca"
            } else {
                "${encontradas.size} série(s) encontrada(s)"
            }

        containerSeries
            .getChildAt(0)
            ?.post {
                containerSeries
                    .getChildAt(0)
                    ?.requestFocus()
            }
    }

    // =========================================================
    // FILTRAR SÉRIES
    // =========================================================

    private fun filtrarSeries(
        termo: String
    ) {

        containerSeries.removeAllViews()

        var encontradas = 0

        for (serie in listaSeries) {

            val nome =
                serie.optString("name", "Série")

            if (nome.contains(termo, ignoreCase = true)) {

                adicionarSerie(
                    nome,
                    serie.optString("series_id", "")
                )

                encontradas++
            }
        }

        if (encontradas == 0) {

            txtMensagemSeries.visibility = View.VISIBLE

            txtMensagemSeries.text =
                "Nenhuma série encontrada para \"$termo\"."

            txtStatus.text = "0 série(s) encontrada(s)"

        } else {

            txtMensagemSeries.visibility = View.GONE

            txtStatus.text =
                "$encontradas série(s) encontrada(s)"

            containerSeries
                .getChildAt(0)
                .post {
                    containerSeries
                        .getChildAt(0)
                        ?.requestFocus()
                }
        }
    }

    // =========================================================
    // FOCO DO CABEÇALHO
    // =========================================================

    private fun configurarFocoCabecalho(
        item: TextView
    ) {

        item.setOnFocusChangeListener { _, temFoco ->

            if (temFoco) {

                item.background =
                    criarFundoComBorda(
                        "#086BC1",
                        "#FFD600"
                    )

            } else {

                item.background =
                    criarFundoItem(
                        "#162638"
                    )
            }
        }
    }

    // =========================================================
    // FUNDO NORMAL
    // =========================================================

    private fun criarFundoItem(
        cor: String
    ): GradientDrawable {

        return GradientDrawable().apply {

            shape =
                GradientDrawable.RECTANGLE

            setColor(
                Color.parseColor(cor)
            )

            cornerRadius =
                dp(8).toFloat()
        }
    }

    // =========================================================
    // FUNDO COM BORDA DE FOCO
    // =========================================================

    private fun criarFundoComBorda(
        corFundo: String,
        corBorda: String
    ): GradientDrawable {

        return GradientDrawable().apply {

            shape =
                GradientDrawable.RECTANGLE

            setColor(
                Color.parseColor(corFundo)
            )

            setStroke(
                dp(3),
                Color.parseColor(corBorda)
            )

            cornerRadius =
                dp(8).toFloat()
        }
    }

    // =========================================================
    // ERRO
    // =========================================================

    private fun mostrarErro(
        mensagem: String
    ) {

        runOnUiThread {

            txtStatus.setTextColor(
                Color.parseColor("#FF5C68")
            )

            txtStatus.text =
                mensagem
        }
    }

    // =========================================================
    // DP
    // =========================================================

    private fun dp(
        valor: Int
    ): Int {

        return (
                valor *
                        resources
                            .displayMetrics
                            .density
                ).toInt()
    }

    private fun adicionarCategoriaBiblioteca(titulo: String, secao: String, tipo: String) {
        val item = TextView(this).apply {
            text = titulo
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(18, 18, 18, 18)
            isFocusable = true
            setOnClickListener {
                startActivity(Intent(this@SeriesActivity, BibliotecaActivity::class.java).apply {
                    putExtra("tipo_secao", tipo)
                    putExtra("secao_inicial", secao)
                })
            }
        }
        containerCategorias.addView(item, 0)
    }
}