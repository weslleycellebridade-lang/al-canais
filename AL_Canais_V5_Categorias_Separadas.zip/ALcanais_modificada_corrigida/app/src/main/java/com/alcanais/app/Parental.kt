package com.alcanais.app

import android.app.Activity
import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

/** Controle parental: com PIN definido, categorias adultas ficam ocultas. */
object Parental {

    @Volatile
    var liberado = false

    private val ocultas = HashSet<String>()

    private val padrao = Regex(
        "(adult|xxx|\\+\\s?18|18\\s?\\+|porn|er[óo]tic|hentai|playboy|\\bsex(o|y)?\\b)",
        RegexOption.IGNORE_CASE
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences("AL_CANAIS", Context.MODE_PRIVATE)

    private fun pin(context: Context): String =
        prefs(context).getString("parental_pin", "") ?: ""

    fun ativo(context: Context): Boolean = pin(context).isNotEmpty()

    fun ehAdulta(nome: String): Boolean = padrao.containsMatchIn(nome)

    /** true = esta categoria deve ficar escondida (e lembra o id para filtrar buscas). */
    fun ocultar(context: Context, tipo: String, id: String, nome: String): Boolean {
        if (!ativo(context) || liberado) return false
        if (ehAdulta(nome)) {
            ocultas.add("$tipo:$id")
            return true
        }
        return false
    }

    fun categoriaOculta(context: Context, tipo: String, id: String): Boolean {
        if (!ativo(context) || liberado) return false
        return ocultas.contains("$tipo:$id")
    }

    fun abrirMenu(activity: Activity, aoFinalizar: () -> Unit) {

        if (!ativo(activity)) {
            pedirPin(activity, "Criar PIN do controle parental (4 a 8 números)") { novo ->
                if (novo.length < 4) {
                    Toast.makeText(activity, "O PIN precisa ter pelo menos 4 números", Toast.LENGTH_LONG).show()
                } else {
                    prefs(activity).edit().putString("parental_pin", novo).apply()
                    liberado = false
                    Toast.makeText(activity, "Controle parental ativado", Toast.LENGTH_LONG).show()
                    aoFinalizar()
                }
            }
            return
        }

        pedirPin(activity, "Digite o PIN") { digitado ->
            if (digitado != pin(activity)) {
                Toast.makeText(activity, "PIN incorreto", Toast.LENGTH_LONG).show()
            } else {
                mostrarOpcoes(activity, aoFinalizar)
            }
        }
    }

    private fun mostrarOpcoes(activity: Activity, aoFinalizar: () -> Unit) {

        val opcoes = arrayOf(
            if (liberado) "Bloquear conteúdo adulto novamente"
            else "Liberar conteúdo adulto (até fechar o app)",
            "Alterar PIN",
            "Desativar controle parental"
        )

        AlertDialog.Builder(activity)
            .setTitle("Controle parental")
            .setItems(opcoes) { _, quel ->
                when (quel) {
                    0 -> {
                        liberado = !liberado
                        Toast.makeText(
                            activity,
                            if (liberado) "Conteúdo adulto liberado" else "Conteúdo adulto bloqueado",
                            Toast.LENGTH_LONG
                        ).show()
                        aoFinalizar()
                    }
                    1 -> pedirPin(activity, "Novo PIN (4 a 8 números)") { novo ->
                        if (novo.length < 4) {
                            Toast.makeText(activity, "O PIN precisa ter pelo menos 4 números", Toast.LENGTH_LONG).show()
                        } else {
                            prefs(activity).edit().putString("parental_pin", novo).apply()
                            Toast.makeText(activity, "PIN alterado", Toast.LENGTH_LONG).show()
                        }
                    }
                    else -> {
                        prefs(activity).edit().remove("parental_pin").apply()
                        liberado = false
                        ocultas.clear()
                        Toast.makeText(activity, "Controle parental desativado", Toast.LENGTH_LONG).show()
                        aoFinalizar()
                    }
                }
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun pedirPin(activity: Activity, titulo: String, aoConfirmar: (String) -> Unit) {

        val campo = EditText(activity)
        campo.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        campo.setSingleLine(true)
        campo.filters = arrayOf(android.text.InputFilter.LengthFilter(8))

        AlertDialog.Builder(activity)
            .setTitle(titulo)
            .setView(campo)
            .setPositiveButton("OK") { _, _ -> aoConfirmar(campo.text.toString().trim()) }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
