package com.alcanais.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class FilmesActivity : BaseActivity() {

    private val serverUrl: String
        get() {
            return getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            ).getString(
                "server_url",
                "http://z1sv.site:80"
            ) ?: "http://z1sv.site:80"
        }

    private lateinit var containerCategorias: LinearLayout
    private lateinit var containerFilmes: LinearLayout

    private lateinit var txtStatus: TextView
    private lateinit var txtMensagemFilmes: TextView

    private lateinit var btnVoltar: TextView
    private lateinit var btnBuscarFilme: TextView

    private var categoriaSelecionadaView: TextView? = null

    // Filmes carregados da categoria atual
    private val listaFilmes = mutableListOf<JSONObject>()

    // Todos os filmes do servidor (carregados só uma vez, na primeira busca)
    private var todosFilmes: List<JSONObject>? = null

    private val limiteResultados = 200

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_filmes)

        // =========================================
        // LIGAÇÃO COM O XML
        // =========================================

        containerCategorias =
            findViewById(R.id.containerCategoriasFilmes)

        containerFilmes =
            findViewById(R.id.containerFilmes)

        txtStatus =
            findViewById(R.id.txtStatusFilmes)

        txtMensagemFilmes =
            findViewById(R.id.txtMensagemFilmes)

        btnVoltar =
            findViewById(R.id.btnVoltarFilmes)

        btnBuscarFilme =
            findViewById(R.id.btnBuscarFilme)

        // =========================================
        // VOLTAR
        // =========================================

        btnVoltar.setOnClickListener {
            finish()
        }

        // =========================================
        // BUSCAR
        // =========================================

        btnBuscarFilme.setOnClickListener {
            abrirBusca()
        }

        // =========================================
        // FOCO DO CABEÇALHO
        // =========================================

        configurarFocoCabecalho(btnVoltar)
        configurarFocoCabecalho(btnBuscarFilme)

        carregarCategorias()
    }

    // =========================================================
    // CARREGAR CATEGORIAS
    // =========================================================

    private fun carregarCategorias() {

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            preferencias.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            preferencias.getString(
                "password",
                ""
            ) ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {

            txtStatus.text =
                "Login não encontrado."

            return
        }

        txtStatus.setTextColor(
            Color.parseColor("#9EADBF")
        )

        txtStatus.text =
            "Carregando categorias..."

        thread {

            var conexao: HttpURLConnection? = null

            try {

                val usuarioCodificado =
                    URLEncoder.encode(
                        usuario,
                        "UTF-8"
                    )

                val senhaCodificada =
                    URLEncoder.encode(
                        senha,
                        "UTF-8"
                    )

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$usuarioCodificado" +
                            "&password=$senhaCodificada" +
                            "&action=get_vod_categories"

                conexao =
                    URL(endereco)
                        .openConnection() as HttpURLConnection

                conexao.requestMethod = "GET"
                conexao.connectTimeout = 15000
                conexao.readTimeout = 15000

                val codigo =
                    conexao.responseCode

                if (codigo != HttpURLConnection.HTTP_OK) {

                    mostrarErro(
                        "Erro do servidor: $codigo"
                    )

                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                val categorias =
                    JSONArray(resposta)

                runOnUiThread {

                    containerCategorias.removeAllViews()
                    adicionarCategoriaBiblioteca("★ Favoritos", "favoritos", "movie")
                    adicionarCategoriaBiblioteca("◷ Recentes", "recentes", "movie")


                    if (categorias.length() == 0) {

                        txtStatus.text =
                            "Nenhuma categoria encontrada."

                        return@runOnUiThread
                    }

                    txtStatus.text =
                        "${categorias.length()} categorias encontradas"

                    for (i in 0 until categorias.length()) {

                        val categoria =
                            categorias.getJSONObject(i)

                        val nome =
                            categoria.optString(
                                "category_name",
                                "Categoria"
                            )

                        val id =
                            categoria.optString(
                                "category_id",
                                ""
                            )

                        adicionarCategoria(
                            nome,
                            id
                        )
                    }

                    // Primeiro foco da tela
                    if (containerCategorias.childCount > 0) {

                        containerCategorias
                            .getChildAt(0)
                            .post {

                                containerCategorias
                                    .getChildAt(0)
                                    .requestFocus()
                            }
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()

                mostrarErro(
                    "Não foi possível carregar as categorias."
                )

            } finally {

                conexao?.disconnect()
            }
        }
    }

    // =========================================================
    // ADICIONAR CATEGORIA
    // =========================================================

    private fun adicionarCategoria(
        nome: String,
        id: String
    ) {

        val item =
            TextView(this)

        item.text =
            "🎬  $nome"

        item.textSize =
            13f

        item.setTextColor(
            Color.WHITE
        )

        item.gravity =
            Gravity.CENTER_VERTICAL

        item.setPadding(
            dp(12),
            0,
            dp(8),
            0
        )

        item.background =
            criarFundoItem(
                "#162638"
            )

        val parametros =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(46)
            )

        parametros.setMargins(
            0,
            0,
            0,
            dp(5)
        )

        item.layoutParams =
            parametros

        item.isClickable = true
        item.isFocusable = true

        // FOCO VISUAL NA TV
        item.setOnFocusChangeListener { _, temFoco ->

            if (temFoco) {

                item.background =
                    criarFundoComBorda(
                        "#086BC1",
                        "#FFD600"
                    )

                item.setTextColor(
                    Color.WHITE
                )

                item.scaleX = 1.02f
                item.scaleY = 1.02f

            } else {

                if (item == categoriaSelecionadaView) {

                    item.background =
                        criarFundoItem(
                            "#086BC1"
                        )

                } else {

                    item.background =
                        criarFundoItem(
                            "#162638"
                        )
                }

                item.setTextColor(
                    Color.WHITE
                )

                item.scaleX = 1f
                item.scaleY = 1f
            }
        }

        item.setOnClickListener {

            destacarCategoria(item)

            txtStatus.text =
                "🎬 $nome"

            carregarFilmes(
                id,
                nome
            )
        }

        containerCategorias.addView(item)
    }

    // =========================================================
    // DESTAQUE DA CATEGORIA SELECIONADA
    // =========================================================

    private fun destacarCategoria(
        selecionada: TextView
    ) {

        categoriaSelecionadaView
            ?.background =
            criarFundoItem(
                "#162638"
            )

        selecionada.background =
            criarFundoItem(
                "#086BC1"
            )

        categoriaSelecionadaView =
            selecionada
    }

    // =========================================================
    // CARREGAR FILMES
    // =========================================================

    private fun carregarFilmes(
        categoriaId: String,
        categoriaNome: String
    ) {

        txtMensagemFilmes.visibility =
            View.VISIBLE

        txtMensagemFilmes.text =
            "Carregando filmes..."

        containerFilmes.removeAllViews()

        listaFilmes.clear()

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            preferencias.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            preferencias.getString(
                "password",
                ""
            ) ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {

            txtMensagemFilmes.text =
                "Login não encontrado."

            return
        }

        thread {

            var conexao: HttpURLConnection? = null

            try {

                val usuarioCodificado =
                    URLEncoder.encode(
                        usuario,
                        "UTF-8"
                    )

                val senhaCodificada =
                    URLEncoder.encode(
                        senha,
                        "UTF-8"
                    )

                val categoriaCodificada =
                    URLEncoder.encode(
                        categoriaId,
                        "UTF-8"
                    )

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$usuarioCodificado" +
                            "&password=$senhaCodificada" +
                            "&action=get_vod_streams" +
                            "&category_id=$categoriaCodificada"

                conexao =
                    URL(endereco)
                        .openConnection() as HttpURLConnection

                conexao.requestMethod =
                    "GET"

                conexao.connectTimeout =
                    15000

                conexao.readTimeout =
                    15000

                val codigo =
                    conexao.responseCode

                if (codigo != HttpURLConnection.HTTP_OK) {

                    mostrarErroFilmes(
                        "Erro do servidor: $codigo"
                    )

                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                val filmes =
                    JSONArray(resposta)

                runOnUiThread {

                    containerFilmes.removeAllViews()

                    listaFilmes.clear()

                    if (filmes.length() == 0) {

                        txtMensagemFilmes.visibility =
                            View.VISIBLE

                        txtMensagemFilmes.text =
                            "Nenhum filme encontrado."

                        return@runOnUiThread
                    }

                    txtMensagemFilmes.visibility =
                        View.GONE

                    txtStatus.text =
                        "🎬 $categoriaNome  •  ${filmes.length()} filmes"

                    for (i in 0 until filmes.length()) {

                        val filme =
                            filmes.getJSONObject(i)

                        listaFilmes.add(filme)

                        adicionarFilme(filme)
                    }

                    // Após carregar, joga o foco para o primeiro filme
                    if (containerFilmes.childCount > 0) {

                        containerFilmes
                            .getChildAt(0)
                            .post {

                                containerFilmes
                                    .getChildAt(0)
                                    .requestFocus()
                            }
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()

                mostrarErroFilmes(
                    "Não foi possível carregar os filmes."
                )

            } finally {

                conexao?.disconnect()
            }
        }
    }

    // =========================================================
    // ADICIONAR FILME
    // =========================================================

    private fun adicionarFilme(
        filme: JSONObject
    ) {

        val nome =
            filme.optString(
                "name",
                "Filme"
            )

        val streamId =
            filme.optString(
                "stream_id",
                ""
            )

        val extensao =
            filme.optString(
                "container_extension",
                "mp4"
            )

        val item =
            TextView(this)

        item.text =
            "▶  $nome"

        item.textSize =
            14f

        item.setTextColor(
            Color.WHITE
        )

        item.gravity =
            Gravity.CENTER_VERTICAL

        item.setPadding(
            dp(16),
            0,
            dp(12),
            0
        )

        item.background =
            criarFundoItem(
                "#162638"
            )

        val parametros =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            )

        parametros.setMargins(
            0,
            0,
            0,
            dp(5)
        )

        item.layoutParams =
            parametros

        item.isClickable = true
        item.isFocusable = true

        // FOCO VISUAL PARA TV
        item.setOnFocusChangeListener { _, temFoco ->

            if (temFoco) {

                item.background =
                    criarFundoComBorda(
                        "#086BC1",
                        "#FFD600"
                    )

                item.setTextColor(
                    Color.WHITE
                )

                item.scaleX = 1.01f
                item.scaleY = 1.04f

            } else {

                item.background =
                    criarFundoItem(
                        "#162638"
                    )

                item.setTextColor(
                    Color.WHITE
                )

                item.scaleX = 1f
                item.scaleY = 1f
            }
        }

        FavUi.ligar(
            this,
            item,
            org.json.JSONObject().apply {
                put("tipo", "vod")
                put("id", streamId)
                put("nome", nome)
                put("extensao", extensao)
            }
        )

        // =============================================
        // OK NO FILME = ABRE DIRETAMENTE O PLAYER
        // =============================================

        item.setOnClickListener {

            if (streamId.isNotEmpty()) {

                abrirDetalhesFilme(
                    streamId,
                    nome,
                    extensao,
                    filme.optString("stream_icon", "")
                )
            }
        }

        containerFilmes.addView(item)
    }

    // =========================================================
    // ABRIR PLAYER DIRETAMENTE
    // =========================================================

    private fun abrirDetalhesFilme(
        streamId: String,
        nome: String,
        extensao: String,
        capa: String
    ) {
        val intent = Intent(this, DetalhesFilmeActivity::class.java)
        intent.putExtra("stream_id", streamId)
        intent.putExtra("filme_nome", nome)
        intent.putExtra("extensao", if (extensao.isNotEmpty()) extensao else "mp4")
        intent.putExtra("capa", capa)
        startActivity(intent)
    }

    // =========================================================
    // BUSCAR FILME
    // =========================================================

    private fun abrirBusca() {

        val campoBusca = EditText(this)

        campoBusca.hint = "Digite o nome do filme"
        campoBusca.setSingleLine(true)
        campoBusca.imeOptions = EditorInfo.IME_ACTION_SEARCH

        val container = LinearLayout(this)

        container.orientation = LinearLayout.VERTICAL

        container.setPadding(
            dp(20),
            dp(8),
            dp(20),
            0
        )

        container.addView(campoBusca)

        val dialogo =
            AlertDialog.Builder(this)
                .setTitle("Buscar em todos os filmes")
                .setView(container)
                .setPositiveButton("BUSCAR", null)
                .setNeutralButton("LIMPAR", null)
                .setNegativeButton("CANCELAR", null)
                .create()

        dialogo.setOnShowListener {

            val botaoBuscar =
                dialogo.getButton(AlertDialog.BUTTON_POSITIVE)

            val botaoLimpar =
                dialogo.getButton(AlertDialog.BUTTON_NEUTRAL)

            val executarBusca: () -> Unit = {

                val termo =
                    campoBusca.text.toString().trim()

                if (termo.isEmpty()) {

                    campoBusca.error =
                        "Digite o nome do filme"

                } else {

                    buscarEmTodosFilmes(termo)

                    dialogo.dismiss()
                }
            }

            botaoBuscar.setOnClickListener {
                executarBusca()
            }

            // LIMPAR = volta para a lista da categoria aberta
            botaoLimpar.setOnClickListener {

                if (listaFilmes.isEmpty()) {

                    containerFilmes.removeAllViews()

                    txtMensagemFilmes.visibility = View.VISIBLE

                    txtMensagemFilmes.text =
                        "Selecione uma categoria"

                } else {

                    filtrarFilmes("")
                }

                dialogo.dismiss()
            }

            campoBusca.setOnEditorActionListener { _, acao, _ ->

                if (acao == EditorInfo.IME_ACTION_SEARCH) {

                    executarBusca()

                    true

                } else {

                    false
                }
            }

            campoBusca.requestFocus()
        }

        dialogo.show()
    }

    // =========================================================
    // BUSCAR EM TODOS OS FILMES
    // =========================================================

    private fun buscarEmTodosFilmes(
        termo: String
    ) {

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            preferencias.getString("username", "") ?: ""

        val senha =
            preferencias.getString("password", "") ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {

            txtStatus.text = "Login não encontrado."

            return
        }

        containerFilmes.removeAllViews()

        txtMensagemFilmes.visibility = View.VISIBLE

        txtMensagemFilmes.text =
            "Buscando \"$termo\" em todos os filmes..."

        thread {

            var conexao: HttpURLConnection? = null

            try {

                var base = todosFilmes

                if (base == null) {

                    val usuarioCodificado =
                        URLEncoder.encode(usuario, "UTF-8")

                    val senhaCodificada =
                        URLEncoder.encode(senha, "UTF-8")

                    val endereco =
                        "$serverUrl/player_api.php" +
                                "?username=$usuarioCodificado" +
                                "&password=$senhaCodificada" +
                                "&action=get_vod_streams"

                    conexao =
                        URL(endereco)
                            .openConnection() as HttpURLConnection

                    conexao.requestMethod = "GET"
                    conexao.connectTimeout = 20000
                    conexao.readTimeout = 60000

                    val codigo = conexao.responseCode

                    if (codigo != HttpURLConnection.HTTP_OK) {

                        runOnUiThread {

                            txtMensagemFilmes.text =
                                "Erro do servidor: $codigo"
                        }

                        return@thread
                    }

                    val resposta =
                        conexao.inputStream
                            .bufferedReader()
                            .use {
                                it.readText()
                            }

                    val array = JSONArray(resposta)

                    val lista = ArrayList<JSONObject>(array.length())

                    for (i in 0 until array.length()) {

                        lista.add(array.getJSONObject(i))
                    }

                    todosFilmes = lista

                    base = lista
                }

                val baseFinal: List<JSONObject> =
                    base ?: emptyList()

                val encontrados =
                    baseFinal.filter {

                        it.optString("name", "")
                            .contains(
                                termo,
                                ignoreCase = true
                            )
                    }

                runOnUiThread {

                    mostrarResultadosFilmes(
                        encontrados,
                        termo
                    )
                }

            } catch (e: Exception) {

                e.printStackTrace()

                runOnUiThread {

                    txtMensagemFilmes.visibility = View.VISIBLE

                    txtMensagemFilmes.text =
                        "Não foi possível buscar. Verifique a conexão."
                }

            } finally {

                conexao?.disconnect()
            }
        }
    }

    private fun mostrarResultadosFilmes(
        encontrados: List<JSONObject>,
        termo: String
    ) {

        containerFilmes.removeAllViews()

        if (encontrados.isEmpty()) {

            txtMensagemFilmes.visibility = View.VISIBLE

            txtMensagemFilmes.text =
                "Nenhum filme encontrado para \"$termo\"."

            txtStatus.text = "0 filme(s) encontrado(s)"

            return
        }

        txtMensagemFilmes.visibility = View.GONE

        for (filme in encontrados.take(limiteResultados)) {

            adicionarFilme(filme)
        }

        txtStatus.text =
            if (encontrados.size > limiteResultados) {
                "Mostrando $limiteResultados de ${encontrados.size} • refine a busca"
            } else {
                "${encontrados.size} filme(s) encontrado(s)"
            }

        containerFilmes
            .getChildAt(0)
            ?.post {
                containerFilmes
                    .getChildAt(0)
                    ?.requestFocus()
            }
    }

    // =========================================================
    // FILTRAR FILMES
    // =========================================================

    private fun filtrarFilmes(
        termo: String
    ) {

        containerFilmes.removeAllViews()

        var encontrados =
            0

        for (filme in listaFilmes) {

            val nome =
                filme.optString(
                    "name",
                    "Filme"
                )

            if (
                nome.contains(
                    termo,
                    ignoreCase = true
                )
            ) {

                adicionarFilme(
                    filme
                )

                encontrados++
            }
        }

        if (encontrados == 0) {

            txtMensagemFilmes.visibility =
                View.VISIBLE

            txtMensagemFilmes.text =
                "Nenhum filme encontrado para \"$termo\"."

        } else {

            txtMensagemFilmes.visibility =
                View.GONE

            txtStatus.text =
                "$encontrados filme(s) encontrado(s)"

            if (containerFilmes.childCount > 0) {

                containerFilmes
                    .getChildAt(0)
                    .requestFocus()
            }
        }
    }

    // =========================================================
    // FOCO DO CABEÇALHO
    // =========================================================

    private fun configurarFocoCabecalho(
        item: TextView
    ) {

        item.setOnFocusChangeListener { _, temFoco ->

            if (temFoco) {

                item.background =
                    criarFundoComBorda(
                        "#086BC1",
                        "#FFD600"
                    )

            } else {

                item.background =
                    criarFundoItem(
                        "#162638"
                    )
            }
        }
    }

    // =========================================================
    // FUNDO NORMAL
    // =========================================================

    private fun criarFundoItem(
        cor: String
    ): GradientDrawable {

        return GradientDrawable().apply {

            shape =
                GradientDrawable.RECTANGLE

            setColor(
                Color.parseColor(cor)
            )

            cornerRadius =
                dp(8).toFloat()
        }
    }

    // =========================================================
    // FUNDO COM BORDA DE FOCO
    // =========================================================

    private fun criarFundoComBorda(
        corFundo: String,
        corBorda: String
    ): GradientDrawable {

        return GradientDrawable().apply {

            shape =
                GradientDrawable.RECTANGLE

            setColor(
                Color.parseColor(corFundo)
            )

            setStroke(
                dp(3),
                Color.parseColor(corBorda)
            )

            cornerRadius =
                dp(8).toFloat()
        }
    }

    // =========================================================
    // ERROS
    // =========================================================

    private fun mostrarErro(
        mensagem: String
    ) {

        runOnUiThread {

            txtStatus.setTextColor(
                Color.parseColor("#FF5C68")
            )

            txtStatus.text =
                mensagem
        }
    }

    private fun mostrarErroFilmes(
        mensagem: String
    ) {

        runOnUiThread {

            txtMensagemFilmes.visibility =
                View.VISIBLE

            txtMensagemFilmes.text =
                mensagem

            txtMensagemFilmes.setTextColor(
                Color.parseColor("#FF5C68")
            )
        }
    }

    // =========================================================
    // DP
    // =========================================================

    private fun dp(
        valor: Int
    ): Int {

        return (
                valor *
                        resources
                            .displayMetrics
                            .density
                ).toInt()
    }

    private fun adicionarCategoriaBiblioteca(titulo: String, secao: String, tipo: String) {
        val item = TextView(this).apply {
            text = titulo
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(18, 18, 18, 18)
            isFocusable = true
            setOnClickListener {
                startActivity(Intent(this@FilmesActivity, BibliotecaActivity::class.java).apply {
                    putExtra("tipo_secao", tipo)
                    putExtra("secao_inicial", secao)
                })
            }
        }
        containerCategorias.addView(item, 0)
    }
}