package com.alcanais.app

import android.content.Intent
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class EpisodiosActivity : BaseActivity() {

    private val serverUrl: String
        get() {
            return getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            ).getString(
                "server_url",
                "http://z1sv.site:80"
            ) ?: "http://z1sv.site:80"
        }

    private lateinit var containerTemporadas: LinearLayout
    private lateinit var containerEpisodios: LinearLayout

    private lateinit var txtStatus: TextView
    private lateinit var txtTituloSerie: TextView
    private lateinit var txtTituloTemporada: TextView
    private lateinit var txtMensagemEpisodios: TextView
    private lateinit var txtEpisodioSelecionado: TextView
    private lateinit var txtInfoEpisodio: TextView
    private lateinit var imgCapaSerie: ImageView
    private lateinit var txtDescricaoSerie: TextView

    private lateinit var btnVoltar: TextView
    private lateinit var btnBuscar: TextView
    private lateinit var btnAssistir: TextView

    // Guarda os episódios recebidos da API
    private var episodiosJson: JSONObject? = null

    // Episódio atualmente selecionado
    private var episodioSelecionadoId = ""
    private var episodioSelecionadoNome = ""
    private var episodioSelecionadoExtensao = "mp4"
    private var serieIdAtual = ""
    private var serieNomeAtual = ""
    private var temporadaSelecionada = ""

    // Itens destacados
    private var itemTemporadaSelecionado: TextView? = null
    private var itemEpisodioSelecionado: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_episodios)

        // =====================================================
        // COMPONENTES
        // =====================================================

        containerTemporadas =
            findViewById(R.id.containerTemporadas)

        containerEpisodios =
            findViewById(R.id.containerEpisodios)

        txtStatus =
            findViewById(R.id.txtStatusEpisodios)

        txtTituloSerie =
            findViewById(R.id.txtTituloSerie)

        txtTituloTemporada =
            findViewById(R.id.txtTituloTemporada)

        txtMensagemEpisodios =
            findViewById(R.id.txtMensagemEpisodios)

        txtEpisodioSelecionado =
            findViewById(R.id.txtEpisodioSelecionado)

        txtInfoEpisodio =
            findViewById(R.id.txtInfoEpisodio)

        imgCapaSerie = findViewById(R.id.imgCapaSerie)
        txtDescricaoSerie = findViewById(R.id.txtDescricaoSerie)

        btnVoltar =
            findViewById(R.id.btnVoltarEpisodios)

        btnBuscar =
            findViewById(R.id.btnBuscarEpisodio)

        btnAssistir =
            findViewById(R.id.btnAssistirEpisodio)

        // =====================================================
        // VOLTAR
        // =====================================================

        btnVoltar.setOnClickListener {
            finish()
        }

        // =====================================================
        // BUSCAR
        // =====================================================

        btnBuscar.setOnClickListener {
            abrirBusca()
        }

        // =====================================================
        // ASSISTIR
        // =====================================================

        btnAssistir.setOnClickListener {

            if (episodioSelecionadoId.isEmpty()) {
                return@setOnClickListener
            }

            abrirPlayer()
        }

        // =====================================================
        // DADOS RECEBIDOS
        // =====================================================

        val seriesId =
            intent.getStringExtra("series_id") ?: ""

        val nomeSerie =
            intent.getStringExtra("serie_nome") ?: "SÉRIE"

        txtTituloSerie.text = nomeSerie

        serieIdAtual = seriesId
        serieNomeAtual = nomeSerie

        // segurar OK / toque longo no título = favoritar a série inteira
        val atualizarTitulo = {
            txtTituloSerie.text =
                if (FavUi.ehFavorito(this, "series", seriesId)) "★ $nomeSerie" else nomeSerie
        }
        atualizarTitulo()
        txtTituloSerie.isFocusable = true
        txtTituloSerie.setOnLongClickListener {
            val adicionado = BibliotecaLocal(this).favorito(
                org.json.JSONObject().apply {
                    put("tipo", "series")
                    put("id", seriesId)
                    put("series_id", seriesId)
                    put("nome", nomeSerie)
                }
            )
            atualizarTitulo()
            android.widget.Toast.makeText(
                this,
                if (adicionado) "Série adicionada aos favoritos ★" else "Série removida dos favoritos",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            true
        }

        if (seriesId.isEmpty()) {

            txtStatus.text =
                "Série não identificada."

            return
        }

        carregarEpisodios(seriesId)
    }

    // =========================================================
    // CARREGAR INFORMAÇÕES DA SÉRIE
    // =========================================================

    private fun carregarEpisodios(
        seriesId: String
    ) {

        val prefs =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            prefs.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            prefs.getString(
                "password",
                ""
            ) ?: ""

        if (usuario.isEmpty() || senha.isEmpty()) {

            txtStatus.text =
                "Login não encontrado."

            return
        }

        txtStatus.text =
            "Carregando temporadas..."

        thread {

            var conexao: HttpURLConnection? = null

            try {

                val u =
                    URLEncoder.encode(
                        usuario,
                        "UTF-8"
                    )

                val s =
                    URLEncoder.encode(
                        senha,
                        "UTF-8"
                    )

                val id =
                    URLEncoder.encode(
                        seriesId,
                        "UTF-8"
                    )

                val endereco =
                    "$serverUrl/player_api.php" +
                            "?username=$u" +
                            "&password=$s" +
                            "&action=get_series_info" +
                            "&series_id=$id"

                conexao =
                    URL(endereco)
                        .openConnection() as HttpURLConnection

                conexao.requestMethod = "GET"
                conexao.connectTimeout = 15000
                conexao.readTimeout = 15000

                val codigo =
                    conexao.responseCode

                if (codigo != HttpURLConnection.HTTP_OK) {

                    mostrarErro(
                        "Erro do servidor: $codigo"
                    )

                    return@thread
                }

                val resposta =
                    conexao.inputStream
                        .bufferedReader()
                        .use {
                            it.readText()
                        }

                val json =
                    JSONObject(resposta)

                val episodios =
                    json.optJSONObject("episodes")

                val infoSerie = json.optJSONObject("info") ?: JSONObject()
                val sinopseSerie = infoSerie.optString("plot", infoSerie.optString("description", ""))
                val generoSerie = infoSerie.optString("genre", "")
                val avaliacaoSerie = infoSerie.optString("rating", "")
                val dataSerie = infoSerie.optString("releaseDate", infoSerie.optString("releasedate", ""))
                val capaSerie = infoSerie.optString("cover", infoSerie.optString("cover_big", ""))
                val metaSerie = listOf(dataSerie, generoSerie, if (avaliacaoSerie.isNotBlank()) "★ $avaliacaoSerie" else "")
                    .filter { it.isNotBlank() }.joinToString(" • ")

                runOnUiThread {
                    txtDescricaoSerie.text = buildString {
                        if (metaSerie.isNotBlank()) append(metaSerie).append("\n\n")
                        append(if (sinopseSerie.isNotBlank()) sinopseSerie else "Descrição não disponível.")
                    }
                    if (capaSerie.isNotBlank()) carregarCapaSerie(capaSerie)

                    containerTemporadas.removeAllViews()
                    containerEpisodios.removeAllViews()

                    if (episodios == null) {

                        txtStatus.text =
                            "Nenhum episódio encontrado."

                        txtMensagemEpisodios.text =
                            "Nenhum episódio disponível."

                        return@runOnUiThread
                    }

                    episodiosJson = episodios

                    val temporadas =
                        episodios.keys()
                            .asSequence()
                            .toList()
                            .sortedBy {
                                it.toIntOrNull() ?: 9999
                            }

                    if (temporadas.isEmpty()) {

                        txtStatus.text =
                            "Nenhuma temporada encontrada."

                        return@runOnUiThread
                    }

                    txtStatus.text =
                        "${temporadas.size} temporadas encontradas"

                    // Cria os botões das temporadas
                    for (temporada in temporadas) {

                        adicionarTemporada(
                            temporada
                        )
                    }

                    // Abre automaticamente a primeira temporada
                    val primeiraTemporada =
                        temporadas.first()

                    mostrarTemporada(
                        primeiraTemporada
                    )

                    // Destaca visualmente o primeiro botão
                    if (containerTemporadas.childCount > 0) {

                        val primeiroItem =
                            containerTemporadas.getChildAt(0)

                        if (primeiroItem is TextView) {

                            destacarTemporada(
                                primeiroItem
                            )
                        }
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()

                mostrarErro(
                    "Não foi possível carregar os episódios."
                )

            } finally {

                conexao?.disconnect()
            }
        }
    }

    // =========================================================
    // ADICIONAR TEMPORADA
    // =========================================================

    private fun adicionarTemporada(
        temporada: String
    ) {

        val item =
            TextView(this)

        item.text =
            "TEMPORADA $temporada"

        item.textSize = 13f

        item.setTextColor(
            Color.WHITE
        )

        item.gravity =
            Gravity.CENTER_VERTICAL

        item.setPadding(
            dp(12),
            0,
            dp(8),
            0
        )

        item.background =
            criarFundoItem(
                "#162638"
            )

        val parametros =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(42)
            )

        parametros.setMargins(
            0,
            0,
            0,
            dp(4)
        )

        item.layoutParams =
            parametros

        item.isClickable = true
        item.isFocusable = true
        item.setOnFocusChangeListener { _, temFoco ->
            if (temFoco) {
                item.background = criarFundoItemComBorda("#163B63", "#00C8FF")
            } else if (item !== itemTemporadaSelecionado) {
                item.background = criarFundoItem("#162638")
            }
        }

        item.setOnClickListener {

            destacarTemporada(item)

            mostrarTemporada(
                temporada
            )
        }

        containerTemporadas.addView(item)
    }

    // =========================================================
    // DESTACAR TEMPORADA
    // =========================================================

    private fun destacarTemporada(
        selecionada: TextView
    ) {

        itemTemporadaSelecionado?.background =
            criarFundoItem(
                "#162638"
            )

        selecionada.background =
            criarFundoItem(
                "#086BC1"
            )

        itemTemporadaSelecionado =
            selecionada
    }

    // =========================================================
    // MOSTRAR EPISÓDIOS DA TEMPORADA
    // =========================================================

    private fun mostrarTemporada(
        temporada: String
    ) {

        temporadaSelecionada =
            temporada

        containerEpisodios
            .removeAllViews()

        itemEpisodioSelecionado =
            null

        episodioSelecionadoId = ""
        episodioSelecionadoNome = ""
        episodioSelecionadoExtensao = "mp4"

        txtTituloTemporada.text =
            "EPISÓDIOS • TEMPORADA $temporada"

        txtEpisodioSelecionado.text =
            "Selecione um episódio"

        txtEpisodioSelecionado.setTextColor(
            Color.parseColor("#9EADBF")
        )

        txtInfoEpisodio.text = ""

        btnAssistir.visibility =
            View.GONE

        val lista =
            episodiosJson
                ?.optJSONArray(temporada)

        if (lista == null ||
            lista.length() == 0
        ) {

            txtMensagemEpisodios.visibility =
                View.VISIBLE

            txtMensagemEpisodios.text =
                "Nenhum episódio nesta temporada."

            return
        }

        txtMensagemEpisodios.visibility =
            View.GONE

        for (
        i in 0 until lista.length()
        ) {

            val episodio =
                lista.getJSONObject(i)

            val titulo =
                episodio.optString(
                    "title",
                    "Episódio ${i + 1}"
                )

            val episodioId =
                episodio.optString(
                    "id",
                    ""
                )

            val extensao =
                episodio.optString(
                    "container_extension",
                    "mp4"
                )

            adicionarEpisodio(
                titulo,
                episodioId,
                extensao,
                i + 1
            )
        }

        txtStatus.text =
            "Temporada $temporada • ${lista.length()} episódios"

        // Na TV, ao abrir uma temporada o primeiro episódio fica pronto para navegação.
        if (containerEpisodios.childCount > 0) {
            val primeiroEpisodio = containerEpisodios.getChildAt(0)
            primeiroEpisodio.isFocusable = true
        }
    }

    // =========================================================
    // ADICIONAR EPISÓDIO
    // =========================================================

    private fun adicionarEpisodio(
        nome: String,
        episodioId: String,
        extensao: String,
        numero: Int
    ) {

        val item =
            TextView(this)

        item.tag = episodioId
        item.text = textoEpisodio(nome, episodioId)

        item.textSize = 13f

        item.setTextColor(
            Color.WHITE
        )

        item.gravity =
            Gravity.CENTER_VERTICAL

        item.setPadding(
            dp(12),
            0,
            dp(8),
            0
        )

        item.background =
            criarFundoItem(
                "#162638"
            )

        val parametros =
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(42)
            )

        parametros.setMargins(
            0,
            0,
            0,
            dp(4)
        )

        item.layoutParams =
            parametros

        item.isClickable = true
        item.isFocusable = true
        item.setOnFocusChangeListener { _, temFoco ->
            if (temFoco) {
                item.background = criarFundoItemComBorda("#163B63", "#00C8FF")
            } else if (item !== itemEpisodioSelecionado) {
                item.background = criarFundoItem("#162638")
            }
        }

        item.setOnClickListener {

            selecionarEpisodio(
                item,
                nome,
                episodioId,
                extensao,
                numero
            )

            // um toque / OK já começa a assistir
            abrirPlayer()
        }

        // segurar OK / toque longo = marcar ou desmarcar como assistido
        item.setOnLongClickListener {
            val bib = BibliotecaLocal(this)
            val novo = !bib.foiVisto(serieIdAtual, episodioId)
            bib.marcarVisto(serieIdAtual, episodioId, novo)
            item.text = textoEpisodio(nome, episodioId)
            android.widget.Toast.makeText(
                this,
                if (novo) "Marcado como assistido ✓" else "Marcado como não assistido",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            true
        }

        containerEpisodios.addView(item)
    }

    private val nomesEpisodios = HashMap<String, String>()

    private fun textoEpisodio(nome: String, episodioId: String): String {
        nomesEpisodios[episodioId] = nome
        val bib = BibliotecaLocal(this)
        if (bib.foiVisto(serieIdAtual, episodioId)) return "✓  $nome"
        val pct = bib.percentuais()["ep:$episodioId"]
        return if (pct != null) "◐  $nome  ($pct%)" else "▶  $nome"
    }

    override fun onResume() {
        super.onResume()
        if (serieIdAtual.isEmpty()) return
        for (i in 0 until containerEpisodios.childCount) {
            val v = containerEpisodios.getChildAt(i) as? TextView ?: continue
            val id = v.tag as? String ?: continue
            val nome = nomesEpisodios[id] ?: continue
            v.text = textoEpisodio(nome, id)
        }
    }

    // =========================================================
    // SELECIONAR EPISÓDIO
    // =========================================================

    private fun selecionarEpisodio(
        item: TextView,
        nome: String,
        episodioId: String,
        extensao: String,
        numero: Int
    ) {

        itemEpisodioSelecionado?.background =
            criarFundoItem(
                "#162638"
            )

        item.background =
            criarFundoItem(
                "#086BC1"
            )

        itemEpisodioSelecionado =
            item

        episodioSelecionadoId =
            episodioId

        episodioSelecionadoNome =
            nome

        episodioSelecionadoExtensao =
            extensao

        txtEpisodioSelecionado.text =
            nome

        txtEpisodioSelecionado.setTextColor(
            Color.WHITE
        )

        txtInfoEpisodio.text =
            "Temporada $temporadaSelecionada • Episódio $numero"

        btnAssistir.visibility =
            View.VISIBLE
    }

    // =========================================================
    // ABRIR PLAYER
    // =========================================================

    private fun abrirPlayer() {

        val intent =
            Intent(
                this,
                PlayerActivity::class.java
            )

        intent.putExtra(
            "stream_id",
            episodioSelecionadoId
        )

        intent.putExtra(
            "canal_nome",
            episodioSelecionadoNome
        )

        intent.putExtra(
            "tipo",
            "series"
        )

        intent.putExtra(
            "extensao",
            episodioSelecionadoExtensao
        )

        intent.putExtra("serie_id", serieIdAtual)
        intent.putExtra("serie_nome", serieNomeAtual)

        startActivity(intent)
    }

    // =========================================================
    // BUSCA
    // =========================================================

    private fun abrirBusca() {

        txtStatus.text =
            "Busca de episódios será adicionada."
    }

    // =========================================================
    // FUNDO DOS ITENS
    // =========================================================

    private fun criarFundoItem(
        cor: String
    ): GradientDrawable {

        return GradientDrawable().apply {

            shape =
                GradientDrawable.RECTANGLE

            setColor(
                Color.parseColor(cor)
            )

            cornerRadius =
                dp(8).toFloat()
        }
    }

    private fun criarFundoItemComBorda(cor: String, borda: String): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.parseColor(cor))
            setStroke(dp(3), Color.parseColor(borda))
            cornerRadius = dp(8).toFloat()
        }
    }

    // =========================================================
    // ERROS
    // =========================================================

    private fun mostrarErro(
        mensagem: String
    ) {

        runOnUiThread {

            txtStatus.setTextColor(
                Color.parseColor("#FF5C68")
            )

            txtStatus.text =
                mensagem
        }
    }

    // =========================================================
    // CONVERSÃO DP
    // =========================================================

    private fun carregarCapaSerie(endereco: String) {
        thread {
            try {
                val conexao = URL(endereco).openConnection()
                conexao.connectTimeout = 10000
                conexao.readTimeout = 10000
                val bitmap = conexao.getInputStream().use { BitmapFactory.decodeStream(it) }
                runOnUiThread {
                    if (bitmap != null) imgCapaSerie.setImageBitmap(bitmap)
                }
            } catch (_: Exception) { }
        }
    }


    private fun dp(
        valor: Int
    ): Int {

        return (
                valor *
                        resources
                            .displayMetrics
                            .density
                ).toInt()
    }
}