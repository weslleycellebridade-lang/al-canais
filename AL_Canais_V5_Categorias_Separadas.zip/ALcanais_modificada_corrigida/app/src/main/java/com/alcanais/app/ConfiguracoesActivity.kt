package com.alcanais.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class ConfiguracoesActivity : BaseActivity() {

    private lateinit var txtUsuario: TextView
    private lateinit var btnTrocarConta: Button
    private lateinit var btnAdicionarLista: Button
    private lateinit var btnDeslogar: Button
    private lateinit var btnParental: Button
    private lateinit var btnVoltar: TextView

    private lateinit var listaManager: ListaManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_configuracoes)

        listaManager = ListaManager(this)

        txtUsuario =
            findViewById(R.id.txtUsuarioConfiguracoes)

        btnTrocarConta =
            findViewById(R.id.btnTrocarConta)

        btnAdicionarLista =
            findViewById(R.id.btnAdicionarLista)

        btnDeslogar =
            findViewById(R.id.btnDeslogar)

        btnVoltar =
            findViewById(R.id.btnVoltarConfiguracoes)

        btnParental =
            findViewById(R.id.btnParental)

        btnParental.setOnClickListener {
            Parental.abrirMenu(this) { atualizarTextoParental() }
        }

        atualizarTextoParental()

        migrarContaAtual()

        mostrarContaAtual()

        btnVoltar.setOnClickListener {
            finish()
        }

        btnTrocarConta.setOnClickListener {
            mostrarListas()
        }

        btnAdicionarLista.setOnClickListener {
            abrirLoginParaAdicionar()
        }

        btnDeslogar.setOnClickListener {
            confirmarSaida()
        }

        // Foco inicial no primeiro botão (controle da TV)
        btnTrocarConta.post {
            btnTrocarConta.requestFocus()
        }
    }

    private fun atualizarTextoParental() {
        btnParental.text =
            if (!Parental.ativo(this)) "CONTROLE PARENTAL"
            else if (Parental.liberado) "PARENTAL: LIBERADO"
            else "PARENTAL: ATIVO"
    }

    // =========================================================
    // MIGRA LOGIN ANTIGO PARA O SISTEMA DE LISTAS
    // =========================================================

    private fun migrarContaAtual() {

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        val usuario =
            preferencias.getString(
                "username",
                ""
            ) ?: ""

        val senha =
            preferencias.getString(
                "password",
                ""
            ) ?: ""

        val servidorAtual =
            preferencias.getString(
                "server_url",
                "http://z1sv.site:80"
            ) ?: "http://z1sv.site:80"

        if (usuario.isEmpty() || senha.isEmpty()) {
            return
        }

        // Procura exatamente a mesma conta:
        // servidor + usuário
        val contaExistente =
            listaManager.obterTodas()
                .firstOrNull { conta ->

                    conta.usuario.equals(
                        usuario,
                        ignoreCase = true
                    ) &&
                            conta.servidor.equals(
                                servidorAtual,
                                ignoreCase = true
                            )
                }

        if (contaExistente != null) {

            if (listaManager.obterAtiva() == null) {

                listaManager.definirAtiva(
                    contaExistente
                )
            }

            return
        }

        // Se ainda não existe, cria a conta
        val novaConta =
            ContaLista(
                id = System.currentTimeMillis().toString(),
                nome = "Lista Principal",
                servidor = servidorAtual,
                usuario = usuario,
                senha = senha
            )

        listaManager.adicionar(
            novaConta
        )

        listaManager.definirAtiva(
            novaConta
        )
    }

    // =========================================================
    // MOSTRA CONTA ATIVA
    // =========================================================

    private fun mostrarContaAtual() {

        val conta =
            listaManager.obterAtiva()

        if (conta != null) {

            txtUsuario.text =
                "Lista ativa: ${conta.nome}\n" +
                        "Usuário: ${conta.usuario}"

        } else {

            val preferencias =
                getSharedPreferences(
                    "AL_CANAIS",
                    MODE_PRIVATE
                )

            val usuario =
                preferencias.getString(
                    "username",
                    ""
                ) ?: ""

            if (usuario.isNotEmpty()) {

                txtUsuario.text =
                    "Usuário conectado: $usuario"

            } else {

                txtUsuario.text =
                    "Nenhuma lista selecionada"
            }
        }
    }

    // =========================================================
    // MOSTRA TODAS AS LISTAS
    // =========================================================

    private fun mostrarListas() {

        val contas =
            listaManager.obterTodas()

        if (contas.isEmpty()) {

            abrirLoginParaAdicionar()

            return
        }

        val ativa =
            listaManager.obterAtiva()

        val opcoes =
            mutableListOf<String>()

        for (conta in contas) {

            val marcador =
                if (conta.id == ativa?.id) {
                    "✓ "
                } else {
                    ""
                }

            opcoes.add(
                "$marcador${conta.nome}\nUsuário: ${conta.usuario}"
            )
        }

        opcoes.add(
            "＋ ADICIONAR NOVA LISTA"
        )

        AlertDialog.Builder(this)
            .setTitle("Minhas listas")
            .setItems(
                opcoes.toTypedArray()
            ) { _, posicao ->

                if (posicao == contas.size) {

                    abrirLoginParaAdicionar()

                } else {

                    mostrarOpcoesConta(
                        contas[posicao]
                    )
                }
            }
            .setNegativeButton(
                "CANCELAR",
                null
            )
            .show()
    }

    // =========================================================
    // OPÇÕES DA CONTA
    // =========================================================

    private fun mostrarOpcoesConta(
        conta: ContaLista
    ) {

        val ativa =
            listaManager.obterAtiva()

        val contaAtiva =
            conta.id == ativa?.id

        val opcoes =
            if (contaAtiva) {

                arrayOf(
                    "Conta ativa",
                    "Renomear lista",
                    "Excluir conta"
                )

            } else {

                arrayOf(
                    "Usar esta conta",
                    "Renomear lista",
                    "Excluir conta"
                )
            }

        AlertDialog.Builder(this)
            .setTitle(conta.nome)
            .setItems(opcoes) { _, posicao ->

                when (posicao) {

                    0 -> {

                        if (contaAtiva) {

                            Toast.makeText(
                                this,
                                "Esta conta já está ativa.",
                                Toast.LENGTH_SHORT
                            ).show()

                        } else {

                            selecionarConta(
                                conta
                            )
                        }
                    }

                    1 -> {

                        mostrarRenomearLista(
                            conta
                        )
                    }

                    2 -> {

                        confirmarExclusao(
                            conta
                        )
                    }
                }
            }
            .setNegativeButton(
                "VOLTAR",
                null
            )
            .show()
    }

    // =========================================================
    // RENOMEAR LISTA
    // =========================================================

    private fun mostrarRenomearLista(
        conta: ContaLista
    ) {

        val campoNome =
            EditText(this)

        campoNome.setText(
            conta.nome
        )

        campoNome.setSelection(
            campoNome.text.length
        )

        campoNome.hint =
            "Nome da lista"

        val margem =
            (
                    24 *
                            resources.displayMetrics.density
                    ).toInt()

        val container =
            FrameLayout(this)

        container.setPadding(
            margem,
            0,
            margem,
            0
        )

        container.addView(
            campoNome
        )

        val dialog =
            AlertDialog.Builder(this)
                .setTitle(
                    "Renomear lista"
                )
                .setMessage(
                    "Digite um nome para identificar esta lista."
                )
                .setView(
                    container
                )
                .setNegativeButton(
                    "CANCELAR",
                    null
                )
                .setPositiveButton(
                    "SALVAR",
                    null
                )
                .create()

        dialog.setOnShowListener {

            dialog.getButton(
                AlertDialog.BUTTON_POSITIVE
            ).setOnClickListener {

                val novoNome =
                    campoNome.text
                        .toString()
                        .trim()

                if (novoNome.isEmpty()) {

                    campoNome.error =
                        "Informe um nome."

                    return@setOnClickListener
                }

                val sucesso =
                    listaManager.renomear(
                        conta.id,
                        novoNome
                    )

                if (sucesso) {

                    Toast.makeText(
                        this,
                        "Lista renomeada.",
                        Toast.LENGTH_SHORT
                    ).show()

                    mostrarContaAtual()

                    dialog.dismiss()

                } else {

                    Toast.makeText(
                        this,
                        "Não foi possível renomear a lista.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        dialog.show()
    }

    // =========================================================
    // SELECIONAR CONTA
    // =========================================================

    private fun selecionarConta(
        conta: ContaLista
    ) {

        listaManager.definirAtiva(
            conta
        )

        Toast.makeText(
            this,
            "${conta.nome} selecionada.",
            Toast.LENGTH_SHORT
        ).show()

        val intent =
            Intent(
                this,
                HomeActivity::class.java
            )

        intent.flags =
            Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK

        startActivity(
            intent
        )

        finish()
    }

    // =========================================================
    // CONFIRMAR EXCLUSÃO
    // =========================================================

    private fun confirmarExclusao(
        conta: ContaLista
    ) {

        AlertDialog.Builder(this)
            .setTitle(
                "Excluir lista"
            )
            .setMessage(
                "Deseja excluir \"${conta.nome}\" deste aparelho?"
            )
            .setNegativeButton(
                "CANCELAR",
                null
            )
            .setPositiveButton(
                "EXCLUIR"
            ) { _, _ ->

                excluirConta(
                    conta
                )
            }
            .show()
    }

    // =========================================================
    // EXCLUIR CONTA
    // =========================================================

    private fun excluirConta(
        conta: ContaLista
    ) {

        val eraAtiva =
            listaManager.obterAtiva()?.id ==
                    conta.id

        listaManager.excluir(
            conta.id
        )

        val restantes =
            listaManager.obterTodas()

        if (eraAtiva) {

            if (restantes.isNotEmpty()) {

                listaManager.definirAtiva(
                    restantes.first()
                )

                Toast.makeText(
                    this,
                    "Lista excluída. Outra lista foi selecionada.",
                    Toast.LENGTH_SHORT
                ).show()

                mostrarContaAtual()

            } else {

                limparLoginAtual()

                abrirTelaLogin()
            }

        } else {

            Toast.makeText(
                this,
                "Lista excluída.",
                Toast.LENGTH_SHORT
            ).show()

            mostrarContaAtual()
        }
    }

    // =========================================================
    // ADICIONAR NOVA LISTA
    // =========================================================

    private fun abrirLoginParaAdicionar() {

        val intent =
            Intent(
                this,
                MainActivity::class.java
            )

        intent.putExtra(
            "adicionar_lista",
            true
        )

        startActivity(
            intent
        )
    }

    // =========================================================
    // CONFIRMAR SAÍDA
    // =========================================================

    private fun confirmarSaida() {

        AlertDialog.Builder(this)
            .setTitle(
                "Desconectar"
            )
            .setMessage(
                "Deseja sair da conta atual? As listas salvas continuarão armazenadas."
            )
            .setNegativeButton(
                "CANCELAR",
                null
            )
            .setPositiveButton(
                "SAIR"
            ) { _, _ ->

                deslogar()
            }
            .show()
    }

    // =========================================================
    // DESLOGAR
    // =========================================================

    private fun deslogar() {

        limparLoginAtual()

        val intent = Intent(this, HomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    // =========================================================
    // LIMPAR LOGIN ATUAL
    // =========================================================

    private fun limparLoginAtual() {

        val preferencias =
            getSharedPreferences(
                "AL_CANAIS",
                MODE_PRIVATE
            )

        preferencias
            .edit()
            .remove("username")
            .remove("password")
            .remove("server_url")
            .remove("lista_ativa_id")
            .apply()
    }

    // =========================================================
    // VOLTAR PARA LOGIN
    // =========================================================

    private fun abrirTelaLogin() {

        val intent =
            Intent(
                this,
                MainActivity::class.java
            )

        intent.flags =
            Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK

        startActivity(
            intent
        )

        finish()
    }

    // =========================================================
    // ATUALIZA AO VOLTAR PARA A TELA
    // =========================================================

    override fun onResume() {
        super.onResume()

        if (::listaManager.isInitialized) {

            mostrarContaAtual()
        }
    }
}