package com.alcanais.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.util.LruCache
import android.widget.TextView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.WeakHashMap
import java.util.concurrent.Executors

/**
 * Carregador simples de ícones/capas com cache em memória e em disco.
 * Mostra a imagem à esquerda do texto do item (compound drawable).
 */
object Imagens {

    private val memoria = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 10).toInt()
    ) {
        override fun sizeOf(chave: String, valor: Bitmap): Int = valor.byteCount / 1024
    }

    private val pool = Executors.newFixedThreadPool(3)
    private val destinos = WeakHashMap<TextView, String>()
    private var limpou = false

    fun icone(view: TextView, url: String?, tamanhoDp: Int = 32) {
        val endereco = url?.trim() ?: ""
        val densidade = view.resources.displayMetrics.density
        val lado = (tamanhoDp * densidade).toInt()

        view.compoundDrawablePadding = (10 * densidade).toInt()

        if (!endereco.startsWith("http")) {
            destinos.remove(view)
            return
        }

        destinos[view] = endereco

        val chave = "$endereco#$lado"
        val pronto = memoria.get(chave)
        if (pronto != null) {
            aplicar(view, pronto)
            return
        }

        val contexto = view.context.applicationContext

        pool.execute {
            val bitmap = obter(contexto, endereco, lado) ?: return@execute
            memoria.put(chave, bitmap)
            view.post {
                if (destinos[view] == endereco) aplicar(view, bitmap)
            }
        }
    }

    private fun aplicar(view: TextView, bitmap: Bitmap) {
        val d = BitmapDrawable(view.resources, bitmap)
        d.setBounds(0, 0, bitmap.width, bitmap.height)
        view.setCompoundDrawables(d, null, null, null)
    }

    private fun obter(contexto: Context, endereco: String, lado: Int): Bitmap? {
        return try {
            val pasta = File(contexto.cacheDir, "img")
            if (!pasta.exists()) pasta.mkdirs()
            limparSeGrande(pasta)

            val arquivo = File(pasta, hash(endereco))

            if (!arquivo.exists() || arquivo.length() == 0L) {
                val conexao = URL(endereco).openConnection() as HttpURLConnection
                conexao.connectTimeout = 8000
                conexao.readTimeout = 8000
                try {
                    if (conexao.responseCode != HttpURLConnection.HTTP_OK) return null
                    val temporario = File(pasta, arquivo.name + ".tmp")
                    conexao.inputStream.use { entrada ->
                        temporario.outputStream().use { saida ->
                            val buffer = ByteArray(8192)
                            var total = 0
                            while (true) {
                                val lidos = entrada.read(buffer)
                                if (lidos < 0) break
                                total += lidos
                                if (total > 3 * 1024 * 1024) return null
                                saida.write(buffer, 0, lidos)
                            }
                        }
                    }
                    temporario.renameTo(arquivo)
                } finally {
                    conexao.disconnect()
                }
            }

            decodificar(arquivo, lado)
        } catch (e: Exception) {
            null
        }
    }

    private fun decodificar(arquivo: File, lado: Int): Bitmap? {
        val opcoes = BitmapFactory.Options()
        opcoes.inJustDecodeBounds = true
        BitmapFactory.decodeFile(arquivo.absolutePath, opcoes)

        if (opcoes.outWidth <= 0 || opcoes.outHeight <= 0) {
            arquivo.delete()
            return null
        }

        var amostra = 1
        while (opcoes.outWidth / (amostra * 2) >= lado && opcoes.outHeight / (amostra * 2) >= lado) {
            amostra *= 2
        }

        val opcoes2 = BitmapFactory.Options()
        opcoes2.inSampleSize = amostra
        val original = BitmapFactory.decodeFile(arquivo.absolutePath, opcoes2) ?: return null

        // desenha centralizado num quadrado, para o texto ficar alinhado
        val escala = minOf(lado.toFloat() / original.width, lado.toFloat() / original.height)
        val w = maxOf(1, (original.width * escala).toInt())
        val h = maxOf(1, (original.height * escala).toInt())
        val reduzido = Bitmap.createScaledBitmap(original, w, h, true)

        val quadro = Bitmap.createBitmap(lado, lado, Bitmap.Config.ARGB_8888)
        Canvas(quadro).drawBitmap(reduzido, (lado - w) / 2f, (lado - h) / 2f, null)

        if (reduzido !== original) reduzido.recycle()
        original.recycle()
        return quadro
    }

    private fun limparSeGrande(pasta: File) {
        if (limpou) return
        limpou = true
        val arquivos = pasta.listFiles() ?: return
        if (arquivos.size > 3000) {
            arquivos.sortedBy { it.lastModified() }.take(1500).forEach { it.delete() }
        }
    }

    private fun hash(texto: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(texto.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
